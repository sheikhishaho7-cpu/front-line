package ir.shahin.frontline

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** نقاشی صحنه‌ی نبرد از بالا. همه‌ی مختصات به واحد خانه است (بوم از قبل مقیاس شده). */
object Gfx {
    private const val DEG = 180f / PI.toFloat()

    // ------------------------------------------------------------ پالت زمین
    private class Theme(
        val grass: Int, val grass2: Int, val road: Int, val road2: Int, val water: Int, val water2: Int,
        val tree: Int, val tree2: Int, val wall: Int, val roof: Int, val roof2: Int, val rub: Int, val sand: Int
    )

    private val themes = arrayOf(
        Theme(0xFF5E8F3B.toInt(), 0xFF6FA146.toInt(), 0xFF9C8B6A.toInt(), 0xFF857553.toInt(), 0xFF2F6FA8.toInt(), 0xFF4A8CC4.toInt(),
            0xFF2D6A2E.toInt(), 0xFF3F8A3F.toInt(), 0xFFB8AFA0.toInt(), 0xFFA6492F.toInt(), 0xFF8A3A26.toInt(), 0xFF7C7870.toInt(), 0xFFC9B48A.toInt()),
        Theme(0xFF6B8F3E.toInt(), 0xFF7C9E4A.toInt(), 0xFFA39270.toInt(), 0xFF8B7A58.toInt(), 0xFF34739E.toInt(), 0xFF4F90B8.toInt(),
            0xFF35662B.toInt(), 0xFF4A8038.toInt(), 0xFFCFC3A8.toInt(), 0xFFB5553A.toInt(), 0xFF8F3F2A.toInt(), 0xFF857E72.toInt(), 0xFFD2BE94.toInt()),
        Theme(0xFFE4EBF2.toInt(), 0xFFF3F7FA.toInt(), 0xFFB9B4B0.toInt(), 0xFF9C9792.toInt(), 0xFF5E8AAE.toInt(), 0xFF8DB1CE.toInt(),
            0xFF2F5A44.toInt(), 0xFFF2F6F8.toInt(), 0xFFC9C6C2.toInt(), 0xFF7E5C4A.toInt(), 0xFFEFF3F6.toInt(), 0xFF9A9A9E.toInt(), 0xFFD9D4CC.toInt()),
        Theme(0xFFD7BC84.toInt(), 0xFFE2CB97.toInt(), 0xFFA78F66.toInt(), 0xFF8E7852.toInt(), 0xFF3E86A6.toInt(), 0xFF63A5BE.toInt(),
            0xFF6E8A3C.toInt(), 0xFF849F4A.toInt(), 0xFFD8C7A2.toInt(), 0xFFB8814F.toInt(), 0xFF98683C.toInt(), 0xFF9C8C70.toInt(), 0xFFC4A874.toInt()),
        Theme(0xFF7A7C76.toInt(), 0xFF878983.toInt(), 0xFF55585C.toInt(), 0xFF45484C.toInt(), 0xFF3C6A8C.toInt(), 0xFF56839F.toInt(),
            0xFF4D6A3F.toInt(), 0xFF5F7F4D.toInt(), 0xFF9A958C.toInt(), 0xFF6D5E55.toInt(), 0xFF554840.toInt(), 0xFF6B6761.toInt(), 0xFF8C8374.toInt())
    )

    private fun h(x: Int, y: Int, k: Int): Float {
        var v = x * 73856093 xor y * 19349663 xor k * 83492791
        v = v xor (v ushr 13)
        v *= 1274126177
        v = v xor (v ushr 16)
        return (v and 0xFFFF) / 65535f
    }

    /** زمین یک‌بار در یک تصویر ساخته می‌شود */
    fun terrain(map: GameMap, px: Int): Bitmap {
        val bmp = Bitmap.createBitmap(map.cols * px, map.rows * px, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val th = themes[map.theme.coerceIn(0, themes.size - 1)]
        val s = px.toFloat()
        c.scale(s, s)
        // پایه
        for (y in 0 until map.rows) for (x in 0 until map.cols) {
            val tp = map.at(x, y)
            val fx = x.toFloat()
            val fy = y.toFloat()
            val base = when (tp) {
                1, 8 -> th.road
                2 -> th.water
                4 -> th.grass
                6 -> th.rub
                else -> th.grass
            }
            Draw.rect(c, fx, fy, fx + 1.02f, fy + 1.02f, 0f, base)
            val v = h(x, y, 1)
            if (tp == 0 || tp == 3 || tp == 5 || tp == 4) {
                Draw.rect(c, fx, fy, fx + 1.02f, fy + 1.02f, 0f, withAlpha(th.grass2, (60 + v * 90).toInt()))
            }
        }
        // لکه‌ها و جزئیات
        for (y in 0 until map.rows) for (x in 0 until map.cols) {
            val tp = map.at(x, y)
            val fx = x.toFloat()
            val fy = y.toFloat()
            when (tp) {
                0 -> {
                    for (i in 0 until 4) {
                        val rx = fx + h(x, y, 10 + i)
                        val ry = fy + h(x, y, 20 + i)
                        Draw.circle(c, rx, ry, 0.05f + h(x, y, 30 + i) * 0.06f, withAlpha(th.grass2, 140))
                    }
                    if (h(x, y, 5) > 0.82f) Draw.oval(c, fx + 0.5f, fy + 0.5f, 0.28f, 0.2f, withAlpha(th.road2, 70))
                }
                1, 8 -> {
                    for (i in 0 until 5) {
                        Draw.circle(c, fx + h(x, y, 40 + i), fy + h(x, y, 50 + i), 0.04f + h(x, y, 60 + i) * 0.04f, withAlpha(th.road2, 150))
                    }
                    if (tp == 1) {
                        if (map.at(x - 1, y) != 1 && map.at(x - 1, y) != 8) Draw.rect(c, fx, fy, fx + 0.1f, fy + 1f, 0f, withAlpha(th.road2, 200))
                        if (map.at(x + 1, y) != 1 && map.at(x + 1, y) != 8) Draw.rect(c, fx + 0.9f, fy, fx + 1f, fy + 1f, 0f, withAlpha(th.road2, 200))
                    }
                }
                2 -> {
                    val ph = h(x, y, 7)
                    Draw.line(c, fx + 0.1f, fy + 0.3f + ph * 0.2f, fx + 0.45f, fy + 0.3f + ph * 0.2f, withAlpha(th.water2, 190), 0.05f)
                    Draw.line(c, fx + 0.5f, fy + 0.7f - ph * 0.2f, fx + 0.9f, fy + 0.7f - ph * 0.2f, withAlpha(th.water2, 190), 0.05f)
                    // ساحل
                    val e = withAlpha(th.sand, 230)
                    if (map.at(x, y - 1) != 2 && map.at(x, y - 1) != 8) Draw.rect(c, fx, fy, fx + 1f, fy + 0.12f, 0f, e)
                    if (map.at(x, y + 1) != 2 && map.at(x, y + 1) != 8) Draw.rect(c, fx, fy + 0.88f, fx + 1f, fy + 1f, 0f, e)
                    if (map.at(x - 1, y) != 2 && map.at(x - 1, y) != 8) Draw.rect(c, fx, fy, fx + 0.12f, fy + 1f, 0f, e)
                    if (map.at(x + 1, y) != 2 && map.at(x + 1, y) != 8) Draw.rect(c, fx + 0.88f, fy, fx + 1f, fy + 1f, 0f, e)
                }
                8 -> {
                    Draw.rect(c, fx, fy, fx + 1f, fy + 1f, 0f, 0xFF8A6238.toInt())
                    for (i in 0 until 4) Draw.line(c, fx, fy + 0.12f + i * 0.25f, fx + 1f, fy + 0.12f + i * 0.25f, 0xFF5D4022.toInt(), 0.04f)
                    Draw.rect(c, fx, fy, fx + 0.1f, fy + 1f, 0f, 0xFF4A3319.toInt())
                    Draw.rect(c, fx + 0.9f, fy, fx + 1f, fy + 1f, 0f, 0xFF4A3319.toInt())
                }
                3 -> {
                    for (i in 0 until 3) {
                        val tx = fx + 0.2f + h(x, y, 70 + i) * 0.6f
                        val ty = fy + 0.2f + h(x, y, 80 + i) * 0.6f
                        val r = 0.3f + h(x, y, 90 + i) * 0.12f
                        Draw.circle(c, tx + 0.07f, ty + 0.08f, r, 0x40000000)
                        Draw.circle(c, tx, ty, r, th.tree)
                        Draw.circle(c, tx - r * 0.2f, ty - r * 0.2f, r * 0.62f, th.tree2)
                        Draw.circle(c, tx - r * 0.35f, ty - r * 0.35f, r * 0.22f, withAlpha(Pal.WHITE, 60))
                    }
                }
                4 -> {
                    val wl = th.wall
                    val rf = if (h(x, y, 3) > 0.5f) th.roof else th.roof2
                    Draw.rect(c, fx + 0.1f, fy + 0.12f, fx + 1.08f, fy + 1.1f, 0.02f, 0x55000000)
                    Draw.rect(c, fx, fy, fx + 1.02f, fy + 1.02f, 0.02f, wl)
                    Draw.rect(c, fx + 0.07f, fy + 0.07f, fx + 0.95f, fy + 0.95f, 0.02f, rf)
                    Draw.rect(c, fx + 0.07f, fy + 0.07f, fx + 0.95f, fy + 0.3f, 0.02f, withAlpha(Pal.WHITE, 40))
                    Draw.line(c, fx + 0.07f, fy + 0.51f, fx + 0.95f, fy + 0.51f, withAlpha(Pal.INK, 90), 0.04f)
                    if (h(x, y, 4) > 0.7f) Draw.rect(c, fx + 0.6f, fy + 0.6f, fx + 0.82f, fy + 0.82f, 0.02f, withAlpha(Pal.INK, 150))
                }
                5 -> {
                    for (i in 0 until 3) for (k in 0 until 2) {
                        Draw.oval(c, fx + 0.2f + i * 0.3f + k * 0.08f, fy + 0.35f + k * 0.3f, 0.17f, 0.11f, 0xFFB29868.toInt())
                        Draw.oval(c, fx + 0.2f + i * 0.3f + k * 0.08f, fy + 0.32f + k * 0.3f, 0.12f, 0.06f, 0xFFCDB482.toInt())
                    }
                }
                6 -> {
                    for (i in 0 until 6) {
                        val rx = fx + h(x, y, 100 + i)
                        val ry = fy + h(x, y, 110 + i)
                        val r = 0.07f + h(x, y, 120 + i) * 0.12f
                        Draw.rect(c, rx - r, ry - r * 0.8f, rx + r, ry + r * 0.8f, 0.02f, if (i % 2 == 0) th.wall else th.roof2)
                    }
                    if (h(x, y, 8) > 0.6f) Draw.circle(c, fx + 0.5f, fy + 0.5f, 0.18f, 0x66000000)
                }
            }
        }
        return bmp
    }

    // ------------------------------------------------------------ پیکره‌ها
    private fun uni(team: Int) = if (team == 0) 0xFF6A8C3A.toInt() else 0xFF8A8D93.toInt()
    private fun uniD(team: Int) = if (team == 0) 0xFF475F26.toInt() else 0xFF5C5F65.toInt()
    private val accents = intArrayOf(0xFFE8C34A.toInt(), 0xFFD9553F.toInt(), 0xFF4A8FD9.toInt(), 0xFFF2F2F2.toInt(), 0xFFE08A2E.toInt(), 0xFF9B6BD6.toInt())

    private fun gun(c: Canvas, x0: Float, len: Float, w: Float, col: Int) {
        Draw.rect(c, x0, -w / 2f, x0 + len, w / 2f, w * 0.3f, col)
    }

    private fun infantry(c: Canvas, role: Role, team: Int, walk: Float, flash: Float) {
        val r = role.size
        val u = uni(team)
        val ud = uniD(team)
        val ac = accents[role.id % accents.size]
        Draw.oval(c, 0.05f * r, 0.12f * r, r * 0.9f, r * 1.05f, 0x44000000)
        // پاها
        val sw = sin(walk) * r * 0.45f
        Draw.circle(c, sw, -r * 0.42f, r * 0.26f, 0xFF2B2B2B.toInt())
        Draw.circle(c, -sw, r * 0.42f, r * 0.26f, 0xFF2B2B2B.toInt())
        // پشتی
        when (role.wpn) {
            12 -> Draw.rect(c, -r * 0.95f, -r * 0.5f, -r * 0.25f, r * 0.5f, r * 0.1f, 0xFF7B6A43.toInt())
            6 -> {
                Draw.rect(c, -r * 1.0f, -r * 0.5f, -r * 0.2f, r * 0.5f, r * 0.2f, 0xFFB5412B.toInt())
            }
            9 -> Draw.rect(c, -r * 0.8f, -r * 0.45f, -r * 0.2f, r * 0.45f, r * 0.1f, Pal.WHITE)
            else -> Draw.rect(c, -r * 0.8f, -r * 0.4f, -r * 0.2f, r * 0.4f, r * 0.12f, ud)
        }
        if (role.wpn == 9) {
            Draw.rect(c, -r * 0.62f, -r * 0.2f, -r * 0.38f, r * 0.2f, 0f, Pal.RED)
            Draw.rect(c, -r * 0.7f, -r * 0.08f, -r * 0.3f, r * 0.08f, 0f, Pal.RED)
        }
        // شانه‌ها
        Draw.oval(c, 0f, 0f, r * 0.55f, r * 0.95f, u)
        Draw.oval(c, -r * 0.05f, 0f, r * 0.35f, r * 0.75f, withAlpha(Pal.WHITE, 36))
        // بازوبند برای تشخیص
        Draw.rect(c, -r * 0.1f, -r * 0.98f, r * 0.2f, -r * 0.7f, 0f, if (team == 0) ac else Pal.RED)
        // سلاح
        val dark = 0xFF2E2E30.toInt()
        val wood = 0xFF6B4A2B.toInt()
        when (role.wpn) {
            1 -> { gun(c, r * 0.2f, r * 1.25f, r * 0.2f, dark); Draw.rect(c, r * 0.5f, r * 0.05f, r * 0.62f, r * 0.45f, 0.01f, dark) }
            2 -> { gun(c, r * 0.1f, r * 1.9f, r * 0.24f, dark); Draw.line(c, r * 1.6f, 0f, r * 1.95f, -r * 0.4f, dark, r * 0.07f); Draw.line(c, r * 1.6f, 0f, r * 1.95f, r * 0.4f, dark, r * 0.07f) }
            3 -> { gun(c, r * 0.1f, r * 2.2f, r * 0.12f, wood); Draw.rect(c, r * 0.6f, -r * 0.16f, r * 1.1f, -r * 0.06f, 0.01f, dark) }
            4 -> { gun(c, r * 0.15f, r * 1.5f, r * 0.22f, wood); gun(c, r * 1.0f, r * 0.65f, r * 0.14f, dark) }
            5, 13 -> { Draw.rect(c, -r * 0.5f, -r * 0.62f, r * 1.9f, -r * 0.36f, r * 0.1f, 0xFF4F5A3A.toInt()); Draw.rect(c, r * 1.7f, -r * 0.7f, r * 2.0f, -r * 0.28f, 0f, dark) }
            6 -> { gun(c, r * 0.2f, r * 1.5f, r * 0.2f, dark); Draw.circle(c, r * 1.75f, 0f, r * 0.17f, Pal.ORANGE) }
            7 -> { Draw.rect(c, r * 0.4f, -r * 0.15f, r * 1.6f, r * 0.15f, 0f, dark); Draw.circle(c, r * 0.4f, 0f, r * 0.32f, 0xFF4A4A4A.toInt()) }
            10 -> { gun(c, r * 0.2f, r * 1.2f, r * 0.2f, dark); for (i in 0 until 3) Draw.circle(c, -r * 0.1f + i * r * 0.22f, r * 0.62f, r * 0.12f, Pal.GOLD_D) }
            8, 9 -> gun(c, r * 0.25f, r * 0.6f, r * 0.13f, dark)
            else -> { gun(c, r * 0.15f, r * 1.5f, r * 0.17f, wood); gun(c, r * 0.85f, r * 0.65f, r * 0.1f, dark) }
        }
        // سر و کلاه
        val helmet = when (role.wpn) {
            9 -> Pal.WHITE
            8 -> if (team == 0) 0xFF3E5BA8.toInt() else 0xFF2B2B2B.toInt()
            else -> ud
        }
        Draw.circle(c, 0f, 0f, r * 0.5f, helmet)
        Draw.circle(c, -r * 0.12f, -r * 0.12f, r * 0.22f, withAlpha(Pal.WHITE, 60))
        if (role.id >= 20) Draw.circle(c, r * 0.1f, 0f, r * 0.14f, ac)
        if (flash > 0f) Draw.circle(c, r * (if (role.wpn == 3) 2.4f else 1.9f), 0f, r * 0.35f, Pal.GOLD)
    }

    private fun wheel(c: Canvas, x: Float, y: Float, r: Float) {
        Draw.rect(c, x - r, y - r * 0.45f, x + r, y + r * 0.45f, r * 0.2f, 0xFF1C1C1E.toInt())
    }

    private fun tracks(c: Canvas, L: Float, W: Float) {
        for (sd in intArrayOf(-1, 1)) {
            val y0 = if (sd < 0) -W * 0.62f else W * 0.34f
            Draw.rect(c, -L * 0.55f, y0, L * 0.55f, y0 + W * 0.28f, W * 0.1f, 0xFF2A2A2A.toInt())
            var x = -L * 0.5f
            while (x < L * 0.5f) {
                Draw.line(c, x, y0, x, y0 + W * 0.28f, 0xFF444446.toInt(), W * 0.03f)
                x += L * 0.1f
            }
        }
    }

    private fun turret(c: Canvas, ang: Float, rad: Float, blen: Float, bw: Float, col: Int, colD: Int, flash: Float) {
        c.save()
        c.rotate(ang * DEG)
        Draw.rect(c, 0f, -bw / 2f, blen, bw / 2f, bw * 0.3f, 0xFF2D2D2F.toInt())
        Draw.rect(c, blen - bw * 0.2f, -bw * 0.7f, blen + bw * 0.5f, bw * 0.7f, 0f, 0xFF1F1F21.toInt())
        Draw.circle(c, 0f, 0f, rad, colD)
        Draw.circle(c, -rad * 0.1f, -rad * 0.1f, rad * 0.82f, col)
        Draw.circle(c, -rad * 0.3f, -rad * 0.3f, rad * 0.25f, withAlpha(Pal.WHITE, 55))
        if (flash > 0f) Draw.circle(c, blen + bw * 1.2f, 0f, bw * 1.5f, Pal.GOLD)
        c.restore()
    }

    private fun vehicle(c: Canvas, role: Role, team: Int, face: Float, turretAng: Float, walk: Float, flash: Float) {
        val r = role.size
        val col = if (team == 0) 0xFF627F38.toInt() else 0xFF80838A.toInt()
        val colD = if (team == 0) 0xFF3F5226.toInt() else 0xFF52555B.toInt()
        val rel = turretAng - face
        val L = r * 2.0f
        val W = r * 1.35f
        val mark = if (team == 0) Pal.WHITE else Pal.RED
        Draw.oval(c, r * 0.1f, r * 0.15f, L * 0.58f, W * 0.7f, 0x44000000)
        when (role.wpn) {
            20 -> {
                for (sx in floatArrayOf(-0.6f, 0.6f)) for (sy in floatArrayOf(-0.6f, 0.6f)) wheel(c, sx * r, sy * r, r * 0.3f)
                Draw.rect(c, -r * 1.0f, -r * 0.55f, r * 1.1f, r * 0.55f, r * 0.2f, col)
                Draw.rect(c, r * 0.3f, -r * 0.45f, r * 0.8f, r * 0.45f, r * 0.1f, withAlpha(Pal.INK, 100))
                Draw.rect(c, -r * 0.7f, -r * 0.4f, r * 0.1f, r * 0.4f, r * 0.1f, colD)
                turret(c, rel, r * 0.2f, r * 0.8f, r * 0.12f, colD, colD, flash)
            }
            21, 37 -> {
                val n = if (role.wpn == 37) 4 else 2
                for (i in 0 until n) { val x = (-0.9f + i * (1.8f / (n - 1))) * r; wheel(c, x, -r * 0.62f, r * 0.26f); wheel(c, x, r * 0.62f, r * 0.26f) }
                Draw.rect(c, -L * 0.52f, -W * 0.45f, L * 0.52f, W * 0.45f, r * 0.2f, col)
                Draw.rect(c, L * 0.2f, -W * 0.3f, L * 0.45f, W * 0.3f, r * 0.1f, colD)
                turret(c, rel, r * 0.36f, r * 1.0f, r * 0.14f, col, colD, flash)
            }
            22 -> {
                tracks(c, L * 0.7f, W * 0.9f)
                Draw.rect(c, -L * 0.5f, -W * 0.45f, L * 0.52f, W * 0.45f, r * 0.15f, col)
                Draw.rect(c, -L * 0.45f, -W * 0.34f, -L * 0.05f, W * 0.34f, r * 0.08f, withAlpha(Pal.INK, 110))
                wheel(c, L * 0.4f, -W * 0.5f, r * 0.3f); wheel(c, L * 0.4f, W * 0.5f, r * 0.3f)
                turret(c, rel, r * 0.2f, r * 0.9f, r * 0.12f, colD, colD, flash)
            }
            23, 62, 24, 64, 65, 66 -> {
                val big = if (role.wpn == 23 || role.wpn == 62) 0.85f else 1f
                tracks(c, L, W)
                Draw.rect(c, -L * 0.5f, -W * 0.46f, L * 0.52f, W * 0.46f, r * 0.15f, col)
                Draw.rect(c, L * 0.2f, -W * 0.3f, L * 0.5f, W * 0.3f, r * 0.1f, withAlpha(Pal.WHITE, 30))
                Draw.circle(c, -L * 0.3f, 0f, r * 0.14f, colD)
                val bl = if (role.wpn == 66) r * 1.7f else if (role.wpn == 24 || role.wpn == 64 || role.wpn == 65) r * 1.35f else r * 1.0f
                turret(c, rel, r * 0.52f * big, bl, r * 0.15f, col, colD, flash)
                Draw.circle(c, -r * 0.1f, 0f, r * 0.1f, mark)
            }
            25, 67 -> {
                tracks(c, L * 1.1f, W * 1.15f)
                Draw.rect(c, -L * 0.55f, -W * 0.52f, L * 0.55f, W * 0.52f, r * 0.12f, col)
                Draw.rect(c, L * 0.2f, -W * 0.38f, L * 0.55f, W * 0.38f, r * 0.1f, colD)
                turret(c, rel, r * 0.62f, r * 1.7f, r * 0.2f, col, colD, flash)
                Draw.circle(c, 0f, 0f, r * 0.1f, mark)
            }
            34 -> {
                tracks(c, L * 1.3f, W * 1.3f)
                Draw.rect(c, -L * 0.62f, -W * 0.6f, L * 0.62f, W * 0.6f, r * 0.1f, col)
                turret(c, rel + 0.12f, r * 0.45f, r * 1.5f, r * 0.17f, col, colD, 0f)
                turret(c, rel - 0.12f, r * 0.45f, r * 1.5f, r * 0.17f, col, colD, flash)
                Draw.circle(c, 0f, 0f, r * 0.55f, withAlpha(colD, 200))
                Draw.circle(c, -r * 0.1f, 0f, r * 0.1f, mark)
            }
            26, 68 -> {
                tracks(c, L, W)
                Draw.rect(c, -L * 0.5f, -W * 0.46f, L * 0.52f, W * 0.46f, r * 0.15f, col)
                Draw.rect(c, -L * 0.3f, -W * 0.34f, L * 0.1f, W * 0.34f, r * 0.1f, colD)
                Draw.rect(c, L * 0.0f, -r * 0.1f, L * 0.9f, r * 0.1f, r * 0.04f, 0xFF2D2D2F.toInt())
                if (flash > 0f) Draw.circle(c, L * 0.95f, 0f, r * 0.25f, Pal.GOLD)
            }
            38, 69 -> {
                tracks(c, L, W)
                Draw.rect(c, -L * 0.5f, -W * 0.46f, L * 0.5f, W * 0.46f, r * 0.15f, col)
                Draw.rect(c, -L * 0.45f, -W * 0.34f, L * 0.2f, W * 0.34f, r * 0.12f, colD)
                turret(c, rel, r * 0.15f, r * 1.7f, r * 0.2f, colD, colD, flash)
            }
            27, 70 -> {
                tracks(c, L * 0.9f, W * 0.9f)
                Draw.rect(c, -L * 0.5f, -W * 0.45f, L * 0.5f, W * 0.45f, r * 0.15f, col)
                c.save(); c.rotate(rel * DEG)
                Draw.rect(c, -r * 0.2f, -r * 0.42f, r * 0.4f, r * 0.42f, 0f, colD)
                Draw.rect(c, 0f, -r * 0.3f, r * 1.4f, -r * 0.18f, 0f, 0xFF2D2D2F.toInt())
                Draw.rect(c, 0f, r * 0.18f, r * 1.4f, r * 0.3f, 0f, 0xFF2D2D2F.toInt())
                if (flash > 0f) Draw.circle(c, r * 1.5f, 0f, r * 0.3f, Pal.GOLD)
                c.restore()
            }
            28 -> {
                Draw.line(c, -r * 1.1f, -r * 0.6f, 0f, 0f, 0xFF4A3A28.toInt(), r * 0.15f)
                Draw.line(c, -r * 1.1f, r * 0.6f, 0f, 0f, 0xFF4A3A28.toInt(), r * 0.15f)
                wheel(c, 0f, -r * 0.7f, r * 0.34f); wheel(c, 0f, r * 0.7f, r * 0.34f)
                turret(c, rel, r * 0.3f, r * 1.7f, r * 0.17f, col, colD, flash)
                Draw.rect(c, r * 0.3f, -r * 0.55f, r * 0.45f, r * 0.55f, 0f, 0xFF3A3A3C.toInt())
            }
            29 -> {
                tracks(c, L, W)
                Draw.rect(c, -L * 0.5f, -W * 0.46f, L * 0.52f, W * 0.46f, r * 0.15f, col)
                Draw.rect(c, -L * 0.45f, -W * 0.2f, -L * 0.15f, W * 0.2f, r * 0.1f, 0xFFB5412B.toInt())
                turret(c, rel, r * 0.46f, r * 1.0f, r * 0.2f, col, colD, 0f)
                c.save(); c.rotate(rel * DEG); Draw.circle(c, r * 1.05f, 0f, r * (if (flash > 0f) 0.36f else 0.2f), Pal.ORANGE); c.restore()
            }
            30 -> {
                for (sx in floatArrayOf(-0.7f, 0.7f)) { wheel(c, sx * r, -r * 0.62f, r * 0.3f); wheel(c, sx * r, r * 0.62f, r * 0.3f) }
                Draw.rect(c, -r * 1.1f, -r * 0.58f, r * 0.5f, r * 0.58f, r * 0.1f, Pal.WHITE)
                Draw.rect(c, r * 0.5f, -r * 0.5f, r * 1.1f, r * 0.5f, r * 0.15f, 0xFFE8E8E8.toInt())
                Draw.rect(c, -r * 0.7f, -r * 0.1f, -r * 0.1f, r * 0.1f, 0f, Pal.RED)
                Draw.rect(c, -r * 0.5f, -r * 0.3f, -r * 0.3f, r * 0.3f, 0f, Pal.RED)
            }
            31 -> {
                tracks(c, L, W)
                Draw.rect(c, -L * 0.5f, -W * 0.46f, L * 0.52f, W * 0.46f, r * 0.15f, col)
                turret(c, rel, r * 0.5f, r * 1.1f, r * 0.15f, col, colD, flash)
                Draw.line(c, -r * 0.6f, -r * 0.3f, -r * 1.2f, -r * 0.8f, 0xFF2D2D2F.toInt(), r * 0.04f)
                Draw.rect(c, -r * 1.2f, -r * 1.0f, -r * 0.7f, -r * 0.7f, 0f, Pal.GOLD)
            }
            32, 71, 42 -> {
                if (role.wpn == 32) { for (sx in floatArrayOf(-0.7f, 0.7f)) { wheel(c, sx * r, -r * 0.62f, r * 0.3f); wheel(c, sx * r, r * 0.62f, r * 0.3f) } } else tracks(c, L, W)
                Draw.rect(c, -L * 0.5f, -W * 0.46f, L * 0.52f, W * 0.46f, r * 0.15f, col)
                c.save(); c.rotate(rel * DEG)
                Draw.rect(c, -r * 0.7f, -r * 0.62f, r * 0.9f, r * 0.62f, r * 0.08f, colD)
                for (i in 0 until 4) for (k in 0 until 2) Draw.circle(c, r * 0.9f - i * r * 0.5f, -r * 0.34f + k * r * 0.68f, r * 0.12f, 0xFFD8A038.toInt())
                c.restore()
            }
            33 -> {
                tracks(c, L, W)
                Draw.rect(c, -L * 0.5f, -W * 0.46f, L * 0.52f, W * 0.46f, r * 0.15f, col)
                Draw.circle(c, 0f, 0f, r * 0.42f, colD)
                Draw.line(c, 0f, 0f, r * 1.0f, -r * 0.3f, Pal.GOLD, r * 0.14f)
                Draw.line(c, r * 1.0f, -r * 0.3f, r * 1.15f, r * 0.2f, Pal.GOLD, r * 0.14f)
                Draw.rect(c, -r * 0.2f, -r * 0.08f, r * 0.2f, r * 0.08f, 0f, Pal.WHITE)
            }
            35 -> {
                wheel(c, -r * 0.8f, 0f, r * 0.4f); wheel(c, r * 0.8f, 0f, r * 0.4f)
                Draw.rect(c, -r * 0.6f, -r * 0.2f, r * 0.7f, r * 0.2f, r * 0.1f, col)
                Draw.rect(c, -r * 0.4f, r * 0.35f, r * 0.5f, r * 0.9f, r * 0.1f, colD)
                wheel(c, 0f, r * 0.9f, r * 0.3f)
                Draw.circle(c, r * 0.1f, 0f, r * 0.2f, 0xFF2B2B2B.toInt())
                turret(c, rel, r * 0.12f, r * 0.7f, r * 0.1f, colD, colD, flash)
            }
            36 -> {
                for (sx in floatArrayOf(-0.8f, 0.2f, 0.9f)) { wheel(c, sx * r, -r * 0.62f, r * 0.3f); wheel(c, sx * r, r * 0.62f, r * 0.3f) }
                Draw.rect(c, -r * 1.2f, -r * 0.58f, r * 0.35f, r * 0.58f, r * 0.08f, 0xFF7A6B4E.toInt())
                Draw.rect(c, r * 0.4f, -r * 0.55f, r * 1.1f, r * 0.55f, r * 0.15f, col)
                Draw.rect(c, r * 0.9f, -r * 0.4f, r * 1.05f, r * 0.4f, 0f, withAlpha(Pal.INK, 120))
            }
            39 -> {
                Draw.rect(c, -L * 0.5f, -W * 0.5f, L * 0.48f, W * 0.5f, r * 0.25f, 0xFF6C8FA3.toInt())
                Draw.tri(c, L * 0.45f, -W * 0.5f, L * 0.45f, W * 0.5f, L * 0.78f, 0f, 0xFF6C8FA3.toInt())
                Draw.rect(c, -L * 0.4f, -W * 0.36f, L * 0.4f, W * 0.36f, r * 0.2f, col)
                turret(c, rel, r * 0.36f, r * 1.0f, r * 0.14f, col, colD, flash)
            }
            43 -> {
                tracks(c, L, W)
                Draw.rect(c, -L * 0.5f, -W * 0.46f, L * 0.5f, W * 0.46f, r * 0.15f, col)
                Draw.rect(c, L * 0.5f, -W * 0.5f, L * 0.7f, W * 0.5f, r * 0.1f, 0xFF2A2A2A.toInt())
                for (i in 0 until 5) Draw.line(c, L * 0.6f, -W * 0.45f + i * W * 0.22f, L * (0.85f + 0.1f * sin(walk + i)), -W * 0.45f + i * W * 0.22f, 0xFF555557.toInt(), r * 0.05f)
            }
            40 -> {
                Draw.circle(c, 0f, 0f, r * 1.05f, 0xFF8E8E88.toInt())
                Draw.circle(c, 0f, 0f, r * 0.86f, 0xFF6F6F6A.toInt())
                Draw.circle(c, 0f, 0f, r * 0.55f, 0xFF3C3C3A.toInt())
                turret(c, rel, r * 0.2f, r * 1.3f, r * 0.14f, 0xFF3C3C3A.toInt(), 0xFF2A2A29.toInt(), flash)
            }
            41 -> {
                Draw.circle(c, 0f, 0f, r * 1.1f, 0xFF8A8A84.toInt())
                Draw.circle(c, 0f, 0f, r * 0.7f, 0xFF4A4A46.toInt())
                turret(c, rel, r * 0.3f, r * 1.6f, r * 0.18f, 0xFF555550.toInt(), 0xFF2E2E2C.toInt(), flash)
            }
            else -> {
                tracks(c, L, W)
                Draw.rect(c, -L * 0.5f, -W * 0.46f, L * 0.5f, W * 0.46f, r * 0.15f, col)
                turret(c, rel, r * 0.45f, r * 1.2f, r * 0.15f, col, colD, flash)
            }
        }
        Draw.circle(c, 0f, 0f, r * 0.06f, withAlpha(Pal.WHITE, 0))
    }

    /** نقاشی یک نیرو در مبدأ (برای پرتره‌ها). */
    fun body(c: Canvas, role: Role, team: Int, face: Float, turret: Float, walk: Float, flash: Float) {
        c.save()
        if (role.kind == 0) {
            c.rotate(face * DEG)
            infantry(c, role, team, walk, flash)
        } else if (role.wpn == 40 || role.wpn == 41) {
            vehicle(c, role, team, 0f, turret, walk, flash)
        } else {
            c.rotate(face * DEG)
            vehicle(c, role, team, face, turret, walk, flash)
        }
        c.restore()
    }

    fun mob(c: Canvas, m: Mob, t: Float) {
        c.save()
        c.translate(m.x, m.y)
        val r = m.role.size
        if (m.dead) {
            val a = (1f - m.deadT / 6f).coerceIn(0f, 1f)
            if (m.role.kind == 0) {
                Draw.oval(c, 0f, 0f, r * 0.9f, r * 0.7f, withAlpha(0xFF3A2A22.toInt(), (120 * a).toInt()))
                Draw.circle(c, 0f, 0f, r * 0.35f, withAlpha(uniD(m.team), (160 * a).toInt()))
            } else {
                Draw.oval(c, 0f, 0f, r * 1.3f, r * 0.95f, withAlpha(0xFF1E1A18.toInt(), (230 * a).toInt()))
                Draw.circle(c, r * 0.1f, 0f, r * 0.55f, withAlpha(0xFF3A3532.toInt(), (230 * a).toInt()))
                if (m.deadT < 4f) {
                    val f = 0.5f + 0.5f * sin(t * 14f + m.id)
                    Draw.circle(c, r * 0.2f, -r * 0.1f, r * (0.18f + 0.1f * f), withAlpha(Pal.ORANGE, (200 * a).toInt()))
                    Draw.circle(c, -r * 0.1f, r * 0.2f, r * 0.12f, withAlpha(Pal.GOLD, (200 * a).toInt()))
                }
            }
            c.restore()
            return
        }
        if (m.selected && m.team == 0) {
            Draw.ring(c, 0f, 0f, r * 1.35f + 0.08f, Pal.GOLD, 0.07f)
        } else {
            Draw.ring(c, 0f, 0f, r * 1.2f, withAlpha(if (m.team == 0) Pal.GREEN else Pal.RED, 90), 0.05f)
        }
        val ghost = m.camo > 0f
        if (ghost) c.save()
        body(c, m.role, m.team, m.face, m.turret, m.walk, m.flash)
        if (ghost) c.restore()
        if (m.fort > 0f) Draw.ring(c, 0f, 0f, r * 1.0f, withAlpha(Pal.BLUE, 160), 0.06f)
        if (m.rally > 0f) Draw.ring(c, 0f, 0f, r * 1.55f + 0.05f * sin(t * 6f), withAlpha(Pal.GOLD, 150), 0.05f)
        if (m.burn > 0f) {
            val f = 0.5f + 0.5f * sin(t * 18f + m.id)
            Draw.circle(c, 0f, 0f, r * (0.45f + 0.2f * f), withAlpha(Pal.ORANGE, 200))
            Draw.circle(c, 0f, -r * 0.1f, r * 0.25f, withAlpha(Pal.GOLD, 220))
        }
        if (m.supp > 0f) {
            Draw.text(c, "!", 0f, -r * 1.6f, 0.55f, Pal.GOLD, 0)
        }
        c.restore()
        // نوار سلامتی
        val hpF = (m.hp / m.maxHp).coerceIn(0f, 1f)
        if (m.team == 0 || hpF < 0.999f) {
            val w = max(0.7f, r * 2.1f)
            val bx = m.x - w / 2f
            val by = m.y - r - 0.36f
            Draw.rect(c, bx - 0.02f, by - 0.02f, bx + w + 0.02f, by + 0.1f, 0.03f, 0xAA000000.toInt())
            Draw.rect(c, bx, by, bx + w * hpF, by + 0.06f, 0.02f, if (hpF > 0.5f) Pal.GREEN else if (hpF > 0.25f) Pal.GOLD else Pal.RED)
        }
    }

    // ------------------------------------------------------------ جلوه‌ها
    fun groundFx(c: Canvas, b: Battle, t: Float) {
        for (cr in b.craters) {
            Draw.oval(c, cr.x, cr.y, cr.r, cr.r * 0.85f, 0x66221A14)
            Draw.oval(c, cr.x, cr.y, cr.r * 0.65f, cr.r * 0.55f, 0x77100A06)
        }
        for (mi in b.mines) {
            if (mi.team == 0) {
                Draw.circle(c, mi.x, mi.y, 0.14f, 0xFF2E2E2E.toInt())
                Draw.circle(c, mi.x, mi.y, 0.05f, if (((t * 3f).toInt() and 1) == 0) Pal.RED else Pal.RED_D)
            }
        }
        for (z in b.zones) {
            val p = z.prog
            val col = if (p >= 1f) Pal.GREEN else if (p < 0f) Pal.RED else Pal.GOLD
            Draw.circle(c, z.cx, z.cy, z.r, withAlpha(col, 40))
            Draw.ring(c, z.cx, z.cy, z.r, withAlpha(col, 200), 0.09f)
            if (p > 0f) Draw.arc(c, z.cx, z.cy, z.r * 0.82f, -90f, 360f * min(1f, p), withAlpha(Pal.GREEN, 230), 0.16f)
            if (p < 0f) Draw.arc(c, z.cx, z.cy, z.r * 0.82f, -90f, 360f * min(1f, -p), withAlpha(Pal.RED, 230), 0.16f)
            // پرچم
            Draw.line(c, z.cx, z.cy + 0.45f, z.cx, z.cy - 0.55f, 0xFF3A3A3A.toInt(), 0.07f)
            Draw.tri(c, z.cx, z.cy - 0.55f, z.cx + 0.6f, z.cy - 0.38f, z.cx, z.cy - 0.2f, col)
        }
        for (f in b.fires) {
            val k = (f.life / 6f).coerceIn(0.2f, 1f)
            for (i in 0 until 7) {
                val a = i * 0.9f + t * 2f
                val rr = f.r * (0.2f + 0.7f * ((i * 37) % 10) / 10f)
                val fx = f.x + cos(a) * rr
                val fy = f.y + sin(a) * rr
                val s = 0.2f + 0.14f * sin(t * 15f + i * 2f)
                Draw.circle(c, fx, fy, s * 1.3f, withAlpha(Pal.ORANGE_D, (150 * k).toInt()))
                Draw.circle(c, fx, fy - 0.05f, s, withAlpha(Pal.ORANGE, (200 * k).toInt()))
                Draw.circle(c, fx, fy - 0.1f, s * 0.5f, withAlpha(Pal.GOLD, (230 * k).toInt()))
            }
        }
        for (d in b.delays) {
            val pul = 0.5f + 0.5f * sin(t * 10f)
            Draw.ring(c, d.x, d.y, max(0.4f, d.rad), withAlpha(Pal.RED, (110 + 100 * pul).toInt()), 0.06f)
            Draw.ring(c, d.x, d.y, max(0.2f, d.rad * 0.4f), withAlpha(Pal.RED, 150), 0.05f)
        }
    }

    fun airFx(c: Canvas, b: Battle, t: Float) {
        for (s in b.smokes) {
            val k = (s.life / s.max).coerceIn(0f, 1f)
            val a = min(1f, k * 3f)
            for (i in 0 until 9) {
                val ang = i * 0.7f + t * 0.3f
                val rr = s.r * (0.25f + 0.55f * ((i * 53) % 10) / 10f)
                Draw.circle(c, s.x + cos(ang) * rr, s.y + sin(ang) * rr, s.r * 0.42f, withAlpha(0xFFD5D8DC.toInt(), (120 * a).toInt()))
            }
            Draw.circle(c, s.x, s.y, s.r * 0.6f, withAlpha(0xFFE6E8EB.toInt(), (130 * a).toInt()))
        }
        for (tr in b.tracers) {
            val a = (tr.life / 0.12f).coerceIn(0f, 1f)
            if (tr.big) Draw.line(c, tr.x1, tr.y1, tr.x2, tr.y2, withAlpha(Pal.ORANGE, (220 * a).toInt()), 0.1f)
            else Draw.line(c, tr.x1, tr.y1, tr.x2, tr.y2, withAlpha(0xFFFFF0A0.toInt(), (230 * a).toInt()), 0.045f)
        }
        for (p in b.projs) {
            val k = (p.t / p.dur).coerceIn(0f, 1f)
            val hgt = if (p.kind == 2 || p.kind == 3) sin(k * PI.toFloat()) * (if (p.kind == 3) 2.6f else 1.1f) else 0f
            Draw.circle(c, p.x + 0.04f, p.y + 0.06f, 0.1f, 0x44000000)
            val col = when (p.kind) { 1 -> Pal.ORANGE; 2 -> 0xFF3B3B3B.toInt(); 3 -> 0xFF4A4A4A.toInt(); else -> Pal.GOLD }
            if (p.kind == 0 || p.kind == 1) {
                val dx = p.x - p.sx
                val dy = p.y - p.sy
                val d = sqrt(dx * dx + dy * dy)
                if (d > 0.01f) {
                    val tl = min(d, 0.9f)
                    Draw.line(c, p.x, p.y, p.x - dx / d * tl, p.y - dy / d * tl, withAlpha(if (p.kind == 1) 0xFFFFD08A.toInt() else 0xFFFFF0A0.toInt(), 160), 0.06f)
                }
            }
            Draw.circle(c, p.x, p.y - hgt, if (p.kind == 3) 0.13f else 0.1f, col)
        }
        for (bl in b.blasts) {
            val p = (1f - bl.life / bl.max).coerceIn(0f, 1f)
            val a = (1f - p)
            when (bl.kind) {
                0 -> {
                    val rr = bl.r * (0.35f + 0.8f * sqrt(p))
                    Draw.circle(c, bl.x, bl.y, rr, withAlpha(0xFF3A3028.toInt(), (110 * a).toInt()))
                    Draw.circle(c, bl.x, bl.y, rr * 0.82f, withAlpha(Pal.ORANGE_D, (230 * a).toInt()))
                    Draw.circle(c, bl.x, bl.y, rr * 0.6f, withAlpha(Pal.ORANGE, (240 * a).toInt()))
                    Draw.circle(c, bl.x, bl.y, rr * 0.34f * (1f - p * 0.5f), withAlpha(0xFFFFF4C0.toInt(), (255 * a).toInt()))
                    Draw.ring(c, bl.x, bl.y, bl.r * (0.5f + 1.1f * p), withAlpha(Pal.WHITE, (120 * a).toInt()), 0.06f)
                }
                2 -> Draw.circle(c, bl.x, bl.y, bl.r * (0.5f + p), withAlpha(0xFFE8DCC8.toInt(), (160 * a).toInt()))
                3 -> {
                    Draw.circle(c, bl.x, bl.y, bl.r * (0.4f + 0.6f * p), withAlpha(Pal.ORANGE, (170 * a).toInt()))
                    Draw.circle(c, bl.x, bl.y, bl.r * (0.2f + 0.3f * p), withAlpha(Pal.GOLD, (200 * a).toInt()))
                }
                4 -> {
                    Draw.ring(c, bl.x, bl.y, bl.r * (0.3f + 0.7f * p), withAlpha(Pal.GREEN, (220 * a).toInt()), 0.1f)
                    Draw.rect(c, bl.x - 0.06f, bl.y - 0.3f, bl.x + 0.06f, bl.y + 0.3f, 0f, withAlpha(Pal.GREEN, (230 * a).toInt()))
                    Draw.rect(c, bl.x - 0.3f, bl.y - 0.06f, bl.x + 0.3f, bl.y + 0.06f, 0f, withAlpha(Pal.GREEN, (230 * a).toInt()))
                }
                5 -> {
                    val pul = 0.5f + 0.5f * sin(t * 12f)
                    Draw.ring(c, bl.x, bl.y, bl.r * (0.9f + 0.1f * pul), withAlpha(Pal.WHITE, (200 * a + 40).toInt()), 0.06f)
                    Draw.line(c, bl.x - bl.r, bl.y, bl.x + bl.r, bl.y, withAlpha(Pal.RED, 200), 0.05f)
                    Draw.line(c, bl.x, bl.y - bl.r, bl.x, bl.y + bl.r, withAlpha(Pal.RED, 200), 0.05f)
                }
                6 -> {
                    Draw.circle(c, bl.x, bl.y - 1.2f * a, 0.45f, withAlpha(Pal.WHITE, 230))
                    Draw.line(c, bl.x, bl.y - 1.2f * a, bl.x, bl.y, withAlpha(Pal.WHITE, 200), 0.04f)
                }
            }
        }
        for (pl in b.planes) {
            val ang = kotlin.math.atan2(pl.vy, pl.vx)
            val big = when (pl.kind) { 0 -> 1.5f; 1 -> 0.9f; else -> 1.1f }
            c.save()
            c.translate(pl.x + 0.5f, pl.y + 0.7f)
            c.rotate(ang * DEG)
            Draw.oval(c, 0f, 0f, 1.2f * big, 0.9f * big, 0x30000000)
            c.restore()
            c.save()
            c.translate(pl.x, pl.y)
            c.rotate(ang * DEG)
            val col = 0xFF5A6E4A.toInt()
            val colD = 0xFF3D4B32.toInt()
            Draw.tri(c, -0.3f * big, 0f, -0.9f * big, -0.55f * big, -0.9f * big, 0.55f * big, colD)
            Draw.tri(c, 0.1f * big, -1.35f * big, 0.1f * big, 1.35f * big, -0.45f * big, 0f, col)
            Draw.oval(c, 0f, 0f, 1.0f * big, 0.2f * big, col)
            Draw.circle(c, 0.55f * big, 0f, 0.1f * big, Pal.CREAM)
            Draw.circle(c, -0.1f * big, 0f, 0.08f * big, Pal.WHITE)
            Draw.circle(c, 0.1f * big, -0.9f * big, 0.1f * big, 0xFF22222A.toInt())
            Draw.circle(c, 0.1f * big, 0.9f * big, 0.1f * big, 0xFF22222A.toInt())
            c.restore()
        }
    }

    // ------------------------------------------------------------ آیکن کارت‌های پشتیبانی (روی صفحه)
    fun cardIcon(c: Canvas, role: Role, cx: Float, cy: Float, s: Float, t: Float) {
        c.save()
        c.translate(cx, cy)
        c.scale(s, s)
        when (role.wpn) {
            50 -> { // بمب‌افکن
                Draw.tri(c, 0f, -0.9f, -0.95f, 0.3f, 0.95f, 0.3f, 0xFF5A6E4A.toInt())
                Draw.oval(c, 0f, 0f, 0.2f, 0.85f, 0xFF6F865C.toInt())
                Draw.tri(c, 0f, 0.7f, -0.4f, 0.95f, 0.4f, 0.95f, 0xFF3D4B32.toInt())
                for (i in -1..1) Draw.circle(c, i * 0.32f, 0.78f + abs(i) * 0.0f, 0.1f, 0xFF222222.toInt())
            }
            51 -> {
                Draw.tri(c, 0f, -0.8f, -0.7f, 0.35f, 0.7f, 0.35f, 0xFF5A6E4A.toInt())
                Draw.oval(c, 0f, 0f, 0.14f, 0.8f, 0xFF7C9468.toInt())
                Draw.line(c, -0.5f, -0.2f, -0.5f, 0.3f, Pal.GOLD, 0.06f); Draw.line(c, 0.5f, -0.2f, 0.5f, 0.3f, Pal.GOLD, 0.06f)
            }
            52 -> {
                Draw.circle(c, 0f, 0f, 0.7f, withAlpha(Pal.BLUE, 120))
                Draw.ring(c, 0f, 0f, 0.7f, Pal.BLUE, 0.07f)
                Draw.tri(c, 0f, -0.5f, -0.5f, 0.35f, 0.5f, 0.35f, 0xFF5A6E4A.toInt())
                Draw.circle(c, 0f, 0f, 0.18f, Pal.WHITE)
            }
            53 -> { // ناوگان
                Draw.tri(c, -0.9f, 0.4f, 0.9f, 0.4f, 0.55f, -0.1f, 0xFF5C6670.toInt())
                Draw.rect(c, -0.8f, 0.25f, 0.8f, 0.5f, 0.05f, 0xFF76808B.toInt())
                Draw.rect(c, -0.2f, -0.25f, 0.3f, 0.3f, 0.05f, 0xFF4A535C.toInt())
                Draw.line(c, 0.1f, -0.1f, 0.85f, -0.3f, 0xFF2D2D2F.toInt(), 0.1f)
                Draw.circle(c, 0.95f, -0.33f, 0.14f, Pal.ORANGE)
            }
            54 -> { // ستاد
                Draw.rect(c, -0.6f, -0.2f, 0.6f, 0.6f, 0.06f, 0xFF6B7D4C.toInt())
                Draw.tri(c, -0.75f, -0.2f, 0.75f, -0.2f, 0f, -0.75f, 0xFF4E5F36.toInt())
                Draw.line(c, 0.5f, -0.2f, 0.5f, -0.95f, 0xFF333333.toInt(), 0.05f)
                Draw.tri(c, 0.5f, -0.95f, 0.9f, -0.8f, 0.5f, -0.65f, Pal.GOLD)
                Draw.rect(c, -0.12f, 0.1f, 0.12f, 0.6f, 0f, 0xFF2E2E2E.toInt())
            }
            55 -> { // چترباز
                c.save()
                Draw.arc(c, 0f, -0.15f, 0.7f, 180f, 180f, Pal.WHITE, 0.16f)
                Draw.line(c, -0.7f, -0.15f, 0f, 0.55f, withAlpha(Pal.WHITE, 220), 0.04f)
                Draw.line(c, 0.7f, -0.15f, 0f, 0.55f, withAlpha(Pal.WHITE, 220), 0.04f)
                Draw.circle(c, 0f, 0.6f, 0.17f, 0xFF4E5F36.toInt())
                c.restore()
            }
            56 -> { // ناپالم
                Draw.circle(c, 0f, 0.1f, 0.6f, Pal.ORANGE_D)
                Draw.circle(c, 0f, 0.05f, 0.45f, Pal.ORANGE)
                Draw.tri(c, -0.3f, 0.1f, 0.3f, 0.1f, 0f, -0.9f, Pal.ORANGE)
                Draw.tri(c, -0.15f, 0.1f, 0.15f, 0.1f, 0f, -0.45f, Pal.GOLD)
            }
            57 -> { // ضدتانک هوایی
                Draw.tri(c, 0f, -0.9f, -0.5f, 0.1f, 0.5f, 0.1f, 0xFF5A6E4A.toInt())
                Draw.rect(c, -0.08f, 0.1f, 0.08f, 0.9f, 0f, Pal.ORANGE)
                Draw.tri(c, -0.08f, 0.9f, 0.08f, 0.9f, 0f, 1.1f, Pal.ORANGE)
            }
            58 -> { // دود
                Draw.circle(c, -0.35f, 0.15f, 0.45f, 0xFFB8BCC2.toInt())
                Draw.circle(c, 0.3f, 0.2f, 0.4f, 0xFFD2D5DA.toInt())
                Draw.circle(c, 0f, -0.25f, 0.5f, 0xFFE4E6EA.toInt())
            }
            59 -> { // توپخانه
                Draw.rect(c, -0.9f, 0.15f, 0.9f, 0.45f, 0.06f, 0xFF4A4A4C.toInt())
                Draw.line(c, -0.3f, 0.2f, 0.7f, -0.55f, 0xFF2D2D2F.toInt(), 0.2f)
                Draw.circle(c, 0.8f, -0.62f, 0.15f, Pal.ORANGE)
                Draw.circle(c, -0.35f, 0.45f, 0.3f, 0xFF2E2E30.toInt())
            }
            60, 61 -> { // امداد
                Draw.circle(c, 0f, 0f, 0.8f, Pal.WHITE)
                Draw.rect(c, -0.15f, -0.55f, 0.15f, 0.55f, 0f, Pal.RED)
                Draw.rect(c, -0.55f, -0.15f, 0.55f, 0.15f, 0f, Pal.RED)
            }
            else -> {
                Draw.circle(c, 0f, 0f, 0.55f, 0xFFB8892F.toInt())
                Draw.line(c, -0.45f, 0.45f, 0.45f, -0.45f, Pal.INK, 0.14f)
                Draw.rect(c, -0.55f, -0.18f, -0.15f, 0.18f, 0f, Pal.WHITE)
            }
        }
        c.restore()
    }

    /** آیکن کارت‌های هواپیما با درمان/تعمیر جدا برای wpn ۶۰ و ۶۱ مشابه بالا */
    fun portrait(c: Canvas, role: Role, cx: Float, cy: Float, size: Float, team: Int, t: Float) {
        if (role.kind == 2) {
            cardIcon(c, role, cx, cy, size * 0.5f, t)
            return
        }
        val r = if (role.kind == 0) role.size * 1.6f else role.size * 1.55f
        val k = size * 0.5f / max(0.5f, r * 1.2f)
        c.save()
        c.translate(cx, cy)
        c.scale(k, k)
        body(c, role, team, -PI.toFloat() / 2f, -PI.toFloat() / 2f, 0f, 0f)
        c.restore()
    }
}
