package ir.shahin.frontline

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** کل بازی روی یک View کشیده می‌شود */
class GameView(context: Context, private val store: Store, private val snd: SoundEngine) : View(context) {

    private enum class Screen { HOME, CAMPAIGN, LOADOUT, BARRACKS, BATTLE, RESULT, ABOUT }

    private class Hit(val id: String, val l: Float, val t: Float, val r: Float, val b: Float)
    private class FT(val text: String, var x: Float, var y: Float, var age: Float, val color: Int)
    private class Mark(val x: Float, val y: Float, var age: Float)

    private var screen = Screen.HOME
    private var W = 0f
    private var H = 0f
    private var s = 1f
    private var tAll = 0f
    private var lastNs = 0L
    private var fade = 0f
    private val rnd = java.util.Random()
    private val hits = ArrayList<Hit>()
    private var pressedId: String? = null
    private val black = 0xFF000000.toInt()
    private var topPad = 0f

    // اسکرول
    private var scrollY = 0f
    private var scrollMax = 0f
    private var scrollVel = 0f
    private var scrL = 0f
    private var scrT = 0f
    private var scrR = 0f
    private var scrB = 0f
    private var hasScroll = false
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    // انتخاب‌ها
    private var curMission = 0
    private var squad = ArrayList<Int>()
    private var filter = 0
    private var selRole = 0
    private var toast = ""
    private var toastT = 0f

    // نبرد
    private var battle: Battle? = null
    private var terrain: Bitmap? = null
    private var camX = 9f
    private var camY = 28f
    private var ppt = 100f
    private var vw = 0f
    private var vh = 0f
    private var paused = false
    private var speed = 1f
    private var aimMob: Mob? = null
    private var aimCard: Card? = null
    private var squadMobs = ArrayList<Mob>()
    private val ftexts = ArrayList<FT>()
    private val marks = ArrayList<Mark>()
    private val seen = HashSet<Int>()
    private var seenT = 0f
    private var shake = 0f
    private var endHandled = false
    private var helpT = 0f
    private val lastSfx = HashMap<String, Float>()
    private var vibT = 0f

    // نتیجه
    private var resWin = false
    private var resStars = 0
    private var resCoins = 0
    private var resKills = 0
    private var resLost = 0
    private var resT = 0f
    private var resNew = ""

    init {
        squad = store.squad()
        if (squad.isEmpty()) squad.addAll(listOf(0, 0, 0, 0))
        snd.sfxOn = store.sfx
        snd.musicOn = store.music
        snd.setTrack(0)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
    }

    // ------------------------------------------------------------ چرخه
    fun handleBack(): Boolean {
        when (screen) {
            Screen.HOME -> return false
            Screen.BATTLE -> {
                if (aimMob != null || aimCard != null) {
                    aimMob = null
                    aimCard = null
                } else paused = !paused
            }
            Screen.RESULT -> go(Screen.CAMPAIGN)
            Screen.LOADOUT -> go(Screen.CAMPAIGN)
            else -> go(Screen.HOME)
        }
        return true
    }

    fun onPauseGame() {
        if (screen == Screen.BATTLE) paused = true
    }

    fun onResumeGame() {
        lastNs = 0L
        invalidate()
    }

    private fun trackFor(sc: Screen): Int = when (sc) {
        Screen.HOME, Screen.ABOUT, Screen.RESULT -> 0
        Screen.BATTLE -> 2 + (curMission % 8)
        else -> 1
    }

    private fun go(sc: Screen) {
        screen = sc
        snd.setTrack(trackFor(sc))
        fade = 1f
        pressedId = null
        scrollY = 0f
        scrollVel = 0f
        hasScroll = false
        if (sc != Screen.BATTLE) {
            aimMob = null
            aimCard = null
        }
        if (sc == Screen.BARRACKS) filter = 0
        if (sc == Screen.LOADOUT) filter = 0
        if (sc == Screen.RESULT) resT = 0f
    }

    private fun say(t: String) {
        toast = t
        toastT = 2.2f
    }

    private fun vibrate(ms: Long) {
        try {
            val v = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            else v.vibrate(ms)
        } catch (e: Throwable) {
        }
    }

    private fun sfx(n: String) {
        val last = lastSfx[n] ?: -1f
        if (tAll - last < 0.07f) return
        lastSfx[n] = tAll
        snd.play(n)
    }

    // ------------------------------------------------------------ لمس
    private fun hitAt(x: Float, y: Float): String? {
        for (i in hits.indices.reversed()) {
            val h = hits[i]
            if (x >= h.l && x <= h.r && y >= h.t && y <= h.b) return h.id
        }
        return null
    }

    private fun inScroll(x: Float, y: Float) = hasScroll && x >= scrL && x <= scrR && y >= scrT && y <= scrB
    private fun inWorld(x: Float, y: Float) = screen == Screen.BATTLE && y < vh && hitAt(x, y) == null

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastX = e.x; lastY = e.y
                dragging = false
                scrollVel = 0f
                pressedId = hitAt(e.x, e.y)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - lastX
                val dy = e.y - lastY
                lastX = e.x; lastY = e.y
                if (!dragging) {
                    val d = sqrt((e.x - downX) * (e.x - downX) + (e.y - downY) * (e.y - downY))
                    if (d > 18f * s) {
                        if (screen == Screen.BATTLE && !paused && downY < vh && (pressedId == null || pressedId == "mini" || pressedId == "world")) dragging = true
                        else if (inScroll(downX, downY)) dragging = true
                        if (dragging) pressedId = null
                    }
                }
                if (dragging) {
                    if (screen == Screen.BATTLE) {
                        camX -= dx / ppt
                        camY -= dy / ppt
                        clampCam()
                    } else {
                        scrollY = (scrollY - dy).coerceIn(0f, scrollMax)
                        scrollVel = -dy
                    }
                } else if (pressedId != null && hitAt(e.x, e.y) != pressedId) pressedId = null
            }
            MotionEvent.ACTION_UP -> {
                val id = hitAt(e.x, e.y)
                val p = pressedId
                pressedId = null
                if (!dragging) {
                    if (id != null && id == p) onTap(id)
                    else if (screen == Screen.BATTLE && id == null && !paused && e.y < vh) worldTap(e.x, e.y)
                }
                dragging = false
            }
            MotionEvent.ACTION_CANCEL -> {
                pressedId = null
                dragging = false
            }
        }
        return true
    }

    private fun clampCam() {
        val b = battle ?: return
        val hw = vw / ppt / 2f
        val hh = vh / ppt / 2f
        camX = if (b.cols <= hw * 2f) b.cols / 2f else camX.coerceIn(hw, b.cols - hw)
        camY = if (b.rows <= hh * 2f) b.rows / 2f else camY.coerceIn(hh, b.rows - hh)
    }

    private fun toWorldX(x: Float) = camX + (x - W / 2f) / ppt
    private fun toWorldY(y: Float) = camY + (y - vh / 2f) / ppt

    // ------------------------------------------------------------ منطق ضربه‌ها
    private fun onTap(id: String) {
        sfx("click")
        when {
            id == "back" -> handleBack()
            id == "music" -> {
                store.music = !store.music; snd.musicOn = store.music
            }
            id == "sfxb" -> {
                store.sfx = !store.sfx; snd.sfxOn = store.sfx
            }
            screen == Screen.HOME -> when (id) {
                "battle" -> go(Screen.CAMPAIGN)
                "barracks" -> go(Screen.BARRACKS)
                "about" -> go(Screen.ABOUT)
            }
            screen == Screen.CAMPAIGN -> if (id.startsWith("m")) {
                val i = id.substring(1).toInt()
                if (missionOpen(i)) {
                    curMission = i
                    go(Screen.LOADOUT)
                } else say("اول مأموریت قبلی را تمام کنید")
            } else if (id == "barracks") go(Screen.BARRACKS)
            screen == Screen.LOADOUT -> loadoutTap(id)
            screen == Screen.BARRACKS -> barracksTap(id)
            screen == Screen.BATTLE -> battleTap(id)
            screen == Screen.RESULT -> when (id) {
                "again" -> go(Screen.LOADOUT)
                "next" -> {
                    curMission = min(curMission + 1, Missions.all.size - 1); go(Screen.LOADOUT)
                }
                "camp" -> go(Screen.CAMPAIGN)
            }
            screen == Screen.ABOUT -> {}
        }
    }

    private fun missionOpen(i: Int) = i == 0 || store.stars(i - 1) > 0

    private fun filtered(owned: Boolean): List<Int> {
        val l = ArrayList<Int>()
        for (r in Roles.all) {
            if (filter == 1 && r.kind != 0) continue
            if (filter == 2 && r.kind != 1) continue
            if (filter == 3 && r.kind != 2) continue
            if (owned && !store.owned(r.id)) continue
            l.add(r.id)
        }
        return l
    }

    private fun squadCost(): Int {
        var n = 0
        for (id in squad) n += Roles.byId(id).cost
        return n
    }

    private fun loadoutTap(id: String) {
        if (id.startsWith("f")) {
            filter = id.substring(1).toInt(); scrollY = 0f
        } else if (id.startsWith("sq")) {
            val i = id.substring(2).toInt()
            if (i in squad.indices) squad.removeAt(i)
        } else if (id.startsWith("r")) {
            val rid = id.substring(1).toInt()
            val r = Roles.byId(rid)
            val units = squad.count { Roles.byId(it).kind != 2 }
            val cards = squad.size - units
            if (r.kind == 2 && cards >= 3) say("حداکثر ۳ کارت پشتیبانی")
            else if (r.kind != 2 && units >= 10) say("حداکثر ۱۰ نیرو")
            else if (squadCost() + r.cost > store.budget()) say("بودجه کافی نیست")
            else squad.add(rid)
        } else if (id == "auto") {
            squad.clear()
            val owned = Roles.all.filter { store.owned(it.id) && store.playerLevel() >= it.unlock }
            val inf = owned.filter { it.kind == 0 }
            val veh = owned.filter { it.kind == 1 }
            var guard = 0
            while (guard++ < 40) {
                val units = squad.size
                if (units >= 10) break
                val pick = (if (units % 3 == 2 && veh.isNotEmpty()) veh else inf).let { if (it.isEmpty()) owned else it }
                val r = pick[rnd.nextInt(pick.size)]
                if (r.kind == 2) continue
                if (squadCost() + r.cost <= store.budget()) squad.add(r.id) else if (units >= 4) break
            }
            if (squad.isEmpty()) squad.add(0)
        } else if (id == "clear") squad.clear()
        else if (id == "start") {
            if (squad.none { Roles.byId(it).kind != 2 }) say("حداقل یک نیرو لازم است")
            else {
                store.saveSquad(squad)
                startBattle()
            }
        }
    }

    private fun barracksTap(id: String) {
        if (id.startsWith("f")) {
            filter = id.substring(1).toInt(); scrollY = 0f
        } else if (id.startsWith("r")) selRole = id.substring(1).toInt()
        else if (id == "buy") {
            val r = Roles.byId(selRole)
            if (store.owned(r.id)) return
            if (store.playerLevel() < r.unlock) say("سطح فرمانده کم است")
            else if (store.coins < r.price) say("سکه کافی نیست")
            else {
                store.coins -= r.price; store.setOwned(r.id); sfx("coin"); say("خریداری شد")
            }
        } else if (id == "up") {
            val r = Roles.byId(selRole)
            val lv = store.level(r.id)
            val cost = upCost(r)
            if (lv >= min(10, store.playerLevel() + 3)) say(if (lv >= 10) "به بالاترین سطح رسیده" else "با پیشروی در مأموریت‌ها سقف بالا می‌رود")
            else if (store.coins < cost) say("سکه کافی نیست")
            else {
                store.coins -= cost; store.setLevel(r.id, lv + 1); sfx("power"); say("ارتقا یافت")
            }
        }
    }

    private fun upCost(r: Role) = 100 * store.level(r.id) + r.price / 4

    // ------------------------------------------------------------ شروع و پایان نبرد
    private fun startBattle() {
        val m = Missions.all[curMission]
        val sq = store.squad()
        val unitIds = sq.filter { Roles.byId(it).kind != 2 }
        val cardIds = sq.filter { Roles.byId(it).kind == 2 }
        val b = Battle(m, unitIds, cardIds) { store.level(it) }
        b.sfx = { n -> sfx(n) }
        b.say = { t, x, y, col -> ftexts.add(FT(t, x, y, 0f, col)); if (ftexts.size > 40) ftexts.removeAt(0) }
        battle = b
        terrain = Gfx.terrain(b.map, 36)
        squadMobs = ArrayList(b.mobs.filter { it.team == 0 })
        ftexts.clear(); marks.clear(); seen.clear()
        paused = false
        speed = 1f
        aimMob = null; aimCard = null
        endHandled = false
        helpT = if (curMission == 0 || store.cleared() == 0) 14f else 0f
        calcBattleLayout()
        var sx = 0f
        var sy = 0f
        for (mb in squadMobs) { sx += mb.x; sy += mb.y }
        camX = sx / max(1, squadMobs.size)
        camY = sy / max(1, squadMobs.size) - 3f
        clampCam()
        go(Screen.BATTLE)
        sfx("alarm")
    }

    private fun finishBattle() {
        val b = battle ?: return
        val m = b.m
        resWin = b.state == 1
        val surv = b.players().size
        resStars = if (resWin) 1 + (if (surv * 2 >= b.startCount) 1 else 0) + (if (b.lostCount == 0) 1 else 0) else 0
        val first = store.stars(m.id) == 0
        resKills = b.killCount
        resLost = b.lostCount
        resCoins = if (resWin) (if (first) m.reward + 25 * resStars else m.reward / 2 + 15 * resStars) + b.killCount * 2 else m.reward / 6 + b.killCount * 2
        val before = store.playerLevel()
        store.coins += resCoins
        store.kills += b.killCount
        if (resWin) store.setStars(m.id, resStars)
        val after = store.playerLevel()
        resNew = ""
        if (after > before) {
            val names = Roles.all.filter { it.unlock in (before + 1)..after }.map { it.name }
            resNew = "سطح فرمانده ${fa(after)}" + (if (names.isNotEmpty()) " — نقش جدید در سربازخانه: " + names.take(3).joinToString("، ") else "")
        }
        go(Screen.RESULT)
        sfx(if (resWin) "win" else "lose")
    }

    // ------------------------------------------------------------ لمس در نبرد
    private fun selected(): List<Mob> = squadMobs.filter { it.selected && !it.dead }

    private fun battleTap(id: String) {
        val b = battle ?: return
        if (paused) {
            when (id) {
                "resume" -> paused = false
                "quit" -> {
                    paused = false; go(Screen.CAMPAIGN)
                }
            }
            return
        }
        when {
            id == "pause" -> paused = true
            id == "speed" -> speed = if (speed > 1f) 1f else 2f
            id == "all" -> {
                val any = squadMobs.any { !it.dead }
                for (m in squadMobs) m.selected = any && !m.dead
            }
            id == "center" -> {
                val sl = selected().ifEmpty { b.players() }
                if (sl.isNotEmpty()) {
                    camX = sl.map { it.x }.average().toFloat(); camY = sl.map { it.y }.average().toFloat(); clampCam()
                }
            }
            id == "cancel" -> {
                aimMob = null; aimCard = null
            }
            id == "mini" -> {
                camX = (lastX - miniL) / miniW * b.cols
                camY = (lastY - miniT) / miniH * b.rows
                clampCam()
            }
            id.startsWith("u") -> {
                val i = id.substring(1).toInt()
                val m = squadMobs.getOrNull(i) ?: return
                if (m.dead) return
                aimMob = null; aimCard = null
                val only = m.selected && squadMobs.count { it.selected && !it.dead } == 1
                for (o in squadMobs) o.selected = false
                m.selected = true
                if (only) {
                    camX = m.x; camY = m.y; clampCam()
                }
            }
            id.startsWith("a") -> {
                val i = id.substring(1).toInt()
                val m = squadMobs.getOrNull(i) ?: return
                if (m.dead || m.role.ab == Ab.NONE) return
                if (m.abT > 0f) {
                    sfx("tick"); return
                }
                if (Roles.needsTarget(m.role)) {
                    aimMob = m; aimCard = null
                } else {
                    if (b.castMob(m, m.x, m.y)) sfx("order")
                }
            }
            id.startsWith("c") -> {
                val i = id.substring(1).toInt()
                val c = b.cards.getOrNull(i) ?: return
                if (c.cd > 0f) {
                    sfx("tick"); return
                }
                if (Roles.needsTarget(c.role)) {
                    aimCard = c; aimMob = null
                } else {
                    val pl = b.players()
                    val cx = if (pl.isEmpty()) camX else pl.map { it.x }.average().toFloat()
                    val cy = if (pl.isEmpty()) camY else pl.map { it.y }.average().toFloat()
                    if (b.castCard(c, cx, cy)) sfx("order")
                }
            }
        }
    }

    private fun worldTap(x: Float, y: Float) {
        val b = battle ?: return
        if (b.state != 0) return
        val wx = toWorldX(x)
        val wy = toWorldY(y)
        val am = aimMob
        val ac = aimCard
        if (am != null) {
            if (!b.castMob(am, wx, wy)) say("اجرا نشد")
            else {
                sfx("order"); b.blasts.add(Blast(wx, wy, 0.8f, 0.5f, 0.5f, 5))
            }
            aimMob = null
            return
        }
        if (ac != null) {
            if (!b.castCard(ac, wx, wy)) say("اجرا نشد")
            else {
                sfx("order"); b.blasts.add(Blast(wx, wy, 0.8f, 0.5f, 0.5f, 5))
            }
            aimCard = null
            return
        }
        // دشمن؟
        var enemy: Mob? = null
        var bd = 1e9f
        for (o in b.mobs) {
            if (o.team != 1 || o.dead || !seen.contains(o.id)) continue
            val d = sqrt((o.x - wx) * (o.x - wx) + (o.y - wy) * (o.y - wy))
            if (d < o.role.size + 0.55f && d < bd) {
                bd = d; enemy = o
            }
        }
        val sel = selected()
        if (enemy != null) {
            if (sel.isEmpty()) return
            b.orderAttack(sel, enemy)
            marks.add(Mark(enemy.x, enemy.y, 0f))
            sfx("order")
            return
        }
        // یار؟
        var friend: Mob? = null
        bd = 1e9f
        for (o in squadMobs) {
            if (o.dead) continue
            val d = sqrt((o.x - wx) * (o.x - wx) + (o.y - wy) * (o.y - wy))
            if (d < o.role.size + 0.45f && d < bd) {
                bd = d; friend = o
            }
        }
        if (friend != null) {
            if (friend.selected && sel.size == 1) friend.selected = false
            else {
                for (o in squadMobs) o.selected = false
                friend.selected = true
            }
            return
        }
        if (sel.isEmpty()) {
            say("ابتدا نیرویی را انتخاب کنید")
            return
        }
        b.orderMove(sel, wx, wy)
        marks.add(Mark(wx, wy, 0f))
        sfx("order")
    }

    // ------------------------------------------------------------ به‌روزرسانی
    private var miniL = 0f
    private var miniT = 0f
    private var miniW = 0f
    private var miniH = 0f
    private var panelRows = 1

    private fun calcBattleLayout() {
        val b = battle
        val n = squadMobs.size + (b?.cards?.size ?: 0)
        panelRows = max(1, ceil(n / 7f).toInt())
        vw = W
        vh = H - (panelRows * 176f * s + 28f * s)
        ppt = W / 10.5f
        if (b != null) clampCam()
    }

    private fun update(dt: Float) {
        if (toastT > 0f) toastT -= dt
        if (scrollVel != 0f && !dragging) {
            scrollY = (scrollY + scrollVel).coerceIn(0f, scrollMax)
            scrollVel *= 0.92f
            if (abs(scrollVel) < 0.5f) scrollVel = 0f
        }
        if (screen == Screen.RESULT) resT += dt
        if (screen == Screen.BATTLE) {
            val b = battle ?: return
            if (!paused) {
                b.update(dt)
                if (speed > 1f) b.update(dt)
                for (f in ftexts) f.age += dt
                ftexts.removeAll { it.age > 1.4f }
                for (m in marks) m.age += dt
                marks.removeAll { it.age > 0.8f }
                if (helpT > 0f) helpT -= dt
                seenT -= dt
                if (seenT <= 0f) {
                    seenT = 0.2f
                    seen.clear()
                    for (o in b.mobs) {
                        if (o.team != 1 || o.dead) continue
                        if (o.flash > 0f) {
                            seen.add(o.id); continue
                        }
                        for (p in squadMobs) {
                            if (p.dead) continue
                            val dd = b.dist(p, o)
                            if (dd < 9.5f && b.visible(p, o, dd) && b.los(p.x, p.y, o.x, o.y)) {
                                seen.add(o.id); break
                            }
                        }
                    }
                }
                if (b.shakeReq > 0f) {
                    shake = max(shake, min(b.shakeReq, 1f)); b.shakeReq = 0f
                    if (shake > 0.5f && tAll - vibT > 0.5f) {
                        vibT = tAll; vibrate(25)
                    }
                }
                if (aimMob?.dead == true) aimMob = null
                if (b.state != 0 && b.endT > 1.6f && !endHandled) {
                    endHandled = true
                    finishBattle()
                }
            }
            shake = max(0f, shake - dt * 2.5f)
        }
    }

    override fun onDraw(c: Canvas) {
        if (width == 0 || height == 0) {
            postInvalidateOnAnimation()
            return
        }
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else ((now - lastNs) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastNs = now
        tAll += dt
        val nw = width.toFloat()
        val nh = height.toFloat()
        if (nw != W || nh != H) {
            W = nw; H = nh; s = W / 1080f
            if (battle != null) calcBattleLayout()
        }
        topPad = 48f * s
        hits.clear()
        hasScroll = false
        update(dt)
        when (screen) {
            Screen.HOME -> drawHome(c)
            Screen.CAMPAIGN -> drawCampaign(c)
            Screen.LOADOUT -> drawLoadout(c)
            Screen.BARRACKS -> drawBarracks(c)
            Screen.BATTLE -> drawBattle(c)
            Screen.RESULT -> drawResult(c)
            Screen.ABOUT -> drawAbout(c)
        }
        if (toastT > 0f) {
            val a = min(1f, toastT * 3f)
            val w = max(500f * s, Draw.textWidth(toast, 40f * s) + 80f * s)
            Draw.rect(c, W / 2f - w / 2f, H * 0.5f - 50f * s, W / 2f + w / 2f, H * 0.5f + 50f * s, 30f * s, withAlpha(0xFF1A1A1A.toInt(), (230 * a).toInt()))
            Draw.text(c, toast, W / 2f, H * 0.5f, 40f * s, withAlpha(Pal.WHITE, (255 * a).toInt()), 0)
        }
        if (fade > 0f) {
            c.drawColor(withAlpha(0xFF0A120C.toInt(), (fade * 255f).toInt()))
            fade = max(0f, fade - dt * 2.8f)
        }
        postInvalidateOnAnimation()
    }

    // ------------------------------------------------------------ ابزار رابط
    private fun btn(
        c: Canvas, id: String, l: Float, t: Float, r: Float, b: Float, label: String,
        col: Int, colD: Int, size: Float, enabled: Boolean = true
    ) {
        val pressed = enabled && pressedId == id
        val depth = 12f * s
        val dy = if (pressed) depth * 0.7f else 0f
        val rad = min((b - t) * 0.28f, 36f * s)
        Draw.rect(c, l, t + depth, r, b, rad, colD)
        Draw.rect(c, l, t + dy, r, b - depth + dy, rad, if (enabled) col else Pal.GRAY_D)
        Draw.rect(c, l + 8f * s, t + dy + 6f * s, r - 8f * s, t + dy + (b - t - depth) * 0.45f, rad * 0.8f, withAlpha(Pal.WHITE, 45))
        if (label.isNotEmpty()) {
            Draw.text(c, label, (l + r) / 2f, (t + b - depth) / 2f + dy, Draw.fit(label, size, (r - l) * 0.9f), Pal.WHITE)
        }
        if (enabled) hits.add(Hit(id, l, t, r, b))
    }

    private fun chip(c: Canvas, id: String, cx: Float, cy: Float, w: Float, label: String, on: Boolean) {
        val h = 70f * s
        btn(c, id, cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f + 12f * s, label,
            if (on) Pal.ORANGE else 0xFF4A5A4A.toInt(), if (on) Pal.ORANGE_D else 0xFF2E3A2E.toInt(), 32f * s)
    }

    private fun coinPill(c: Canvas, rightX: Float, cy: Float) {
        val w = 260f * s
        val h = 70f * s
        Draw.rect(c, rightX - w, cy - h / 2f, rightX, cy + h / 2f, h / 2f, withAlpha(black, 130))
        Draw.coin(c, rightX - w + 40f * s, cy, 27f * s)
        Draw.text(c, fa(store.coins), rightX - w / 2f + 28f * s, cy, 42f * s, Pal.GOLD)
    }

    private fun backButton(c: Canvas) {
        btn(c, "back", 28f * s, topPad, 230f * s, topPad + 92f * s, "بازگشت", 0xFF3F6FA8.toInt(), 0xFF264A78.toInt(), 36f * s)
    }

    private fun bg(c: Canvas) {
        val n = 24
        val h = H / n
        for (i in 0 until n) {
            Draw.rect(c, 0f, i * h, W, (i + 1) * h + 2f, 0f, mix(0xFF0E1A12.toInt(), 0xFF2B3C27.toInt(), i / (n - 1f)))
        }
        // نقش پس‌زمینه: خطوط مورب محو
        var x = -H
        while (x < W) {
            Draw.line(c, x + (tAll * 10f % (80f * s)), 0f, x + H + (tAll * 10f % (80f * s)), H, withAlpha(Pal.WHITE, 8), 24f * s)
            x += 140f * s
        }
    }

    private fun panel(c: Canvas, l: Float, t: Float, r: Float, b: Float, col: Int = 0xCC0F1A12.toInt()) {
        Draw.rect(c, l, t, r, b, 28f * s, col)
        Draw.frame(c, l, t, r, b, 28f * s, withAlpha(Pal.WHITE, 40), 3f * s)
    }

    private fun txt(c: Canvas, text: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.CENTER) {
        Draw.text(c, text, x, y, size, color, 0x66000000, align)
    }

    private fun clsColor(r: Role) = when (r.kind) { 0 -> Pal.GREEN; 1 -> Pal.ORANGE; else -> Pal.BLUE }

    // ------------------------------------------------------------ صفحه‌ی اصلی
    private fun drawHome(c: Canvas) {
        bg(c)
        // آسمان آتشین و افق
        val hz = H * 0.62f
        Draw.rect(c, 0f, hz - 200f * s, W, hz, 0f, withAlpha(Pal.ORANGE_D, 40))
        Draw.rect(c, 0f, hz - 90f * s, W, hz, 0f, withAlpha(Pal.ORANGE, 40))
        // ساختمان‌های ویران
        for (i in 0 until 9) {
            val bx = i * 140f * s - 40f * s
            val bh = (120f + ((i * 73) % 5) * 55f) * s
            Draw.rect(c, bx, hz - bh, bx + 118f * s, hz + 4f, 0f, 0xFF161E18.toInt())
            for (k in 0 until 3) Draw.rect(c, bx + 18f * s, hz - bh + 24f * s + k * 44f * s, bx + 40f * s, hz - bh + 46f * s + k * 44f * s, 0f, withAlpha(Pal.GOLD, if ((i + k) % 3 == 0) 110 else 0))
        }
        // انفجارهای دوردست
        val ph = (tAll * 0.6f) % 3f
        val ex = W * (0.2f + 0.6f * ((tAll / 3f).toInt() * 0.37f % 1f))
        if (ph < 0.6f) {
            val k = ph / 0.6f
            Draw.circle(c, ex, hz - 60f * s, 70f * s * (0.4f + k), withAlpha(Pal.ORANGE, (200 * (1f - k)).toInt()))
            Draw.circle(c, ex, hz - 60f * s, 36f * s * (0.4f + k), withAlpha(0xFFFFF4C0.toInt(), (230 * (1f - k)).toInt()))
        }
        // زمین
        Draw.rect(c, 0f, hz, W, H, 0f, 0xFF1B2A1B.toInt())
        Draw.rect(c, 0f, hz, W, hz + 14f * s, 0f, 0xFF2D4229.toInt())
        // تانک و سربازان روی افق
        val tx = ((tAll * 40f * s) % (W + 700f * s)) - 350f * s
        c.save(); c.translate(tx, hz + 130f * s); c.scale(120f * s, 120f * s)
        Gfx.body(c, Roles.byId(34), 0, 0f, 0f, tAll * 3f, 0f)
        c.restore()
        for (i in 0 until 4) {
            c.save(); c.translate(tx - 330f * s - i * 140f * s, hz + 250f * s + (i % 2) * 40f * s); c.scale(150f * s, 150f * s)
            Gfx.body(c, Roles.byId(if (i == 1) 2 else 0), 0, 0f, 0f, tAll * 9f + i, 0f)
            c.restore()
        }
        // عنوان
        val ty = H * 0.18f
        Draw.star(c, W / 2f, ty - 110f * s, 60f * s, 26f * s, 5, 0f, Pal.GOLD)
        txt(c, "خط مقدم", W / 2f, ty + 40f * s, 190f * s, Pal.CREAM)
        txt(c, "نبرد جبهه‌ها · ۸۰ نقش · ۱۲ مأموریت", W / 2f, ty + 170f * s, 40f * s, Pal.GOLD)
        coinPill(c, W - 28f * s, topPad + 40f * s)
        txt(c, "سطح فرمانده ${fa(store.playerLevel())}", 40f * s, topPad + 40f * s, 40f * s, Pal.CREAM, Paint.Align.LEFT)
        val bx1 = W * 0.12f
        val bx2 = W * 0.88f
        val y0 = H * 0.40f
        btn(c, "battle", bx1, y0, bx2, y0 + 150f * s, "شروع نبرد", Pal.GREEN, Pal.GREEN_D, 70f * s)
        btn(c, "barracks", bx1, y0 + 190f * s, bx2, y0 + 320f * s, "سربازخانه", Pal.ORANGE, Pal.ORANGE_D, 56f * s)
        btn(c, "about", bx1, y0 + 360f * s, bx2, y0 + 480f * s, "راهنما و درباره", 0xFF3F6FA8.toInt(), 0xFF264A78.toInt(), 46f * s)
        chip(c, "music", W * 0.3f, H - 150f * s, 360f * s, if (store.music) "موسیقی: روشن" else "موسیقی: خاموش", store.music)
        chip(c, "sfxb", W * 0.7f, H - 150f * s, 360f * s, if (store.sfx) "صدا: روشن" else "صدا: خاموش", store.sfx)
        txt(c, "طراح و سازنده: شاهین شیخ کانلو", W / 2f, H - 50f * s, 34f * s, withAlpha(Pal.CREAM, 200))
    }

    // ------------------------------------------------------------ مأموریت‌ها
    private fun drawCampaign(c: Canvas) {
        bg(c)
        backButton(c)
        coinPill(c, W - 28f * s, topPad + 46f * s)
        txt(c, "نقشه‌ی نبرد", W / 2f, topPad + 150f * s, 72f * s, Pal.CREAM)
        val top = topPad + 220f * s
        val bottom = H - 190f * s
        val ch = 250f * s
        val gap = 26f * s
        val total = Missions.all.size * (ch + gap) + gap
        scrL = 0f; scrT = top; scrR = W; scrB = bottom; hasScroll = true
        scrollMax = max(0f, total - (bottom - top))
        c.save()
        c.clipRect(0f, top, W, bottom)
        for (i in Missions.all.indices) {
            val m = Missions.all[i]
            val t = top + gap + i * (ch + gap) - scrollY
            if (t > bottom || t + ch < top) continue
            val l = 36f * s
            val r = W - 36f * s
            val open = missionOpen(i)
            val st = store.stars(i)
            val col = if (!open) 0xAA1A1F1A.toInt() else if (st > 0) 0xCC1E3A22.toInt() else 0xCC3A3318.toInt()
            Draw.rect(c, l, t, r, t + ch, 30f * s, col)
            Draw.frame(c, l, t, r, t + ch, 30f * s, if (!open) withAlpha(Pal.WHITE, 30) else if (st > 0) Pal.GREEN else Pal.GOLD, 4f * s)
            Draw.circle(c, r - 80f * s, t + 85f * s, 52f * s, if (open) Pal.ORANGE_D else Pal.GRAY_D)
            txt(c, fa(i + 1), r - 80f * s, t + 85f * s, 52f * s, Pal.WHITE)
            if (open) {
                txt(c, m.name, r - 160f * s, t + 62f * s, 52f * s, Pal.CREAM, Paint.Align.RIGHT)
                txt(c, Missions.typeNames[m.type] + " · " + Missions.themeNames[m.theme], r - 160f * s, t + 126f * s, 34f * s, Pal.GOLD, Paint.Align.RIGHT)
                txt(c, "سختی", r - 40f * s, t + 186f * s, 34f * s, Pal.ORANGE, Paint.Align.RIGHT)
                for (k in 0 until 1 + m.diff / 2) Draw.star(c, r - 170f * s - k * 40f * s, t + 186f * s, 17f * s, 8f * s, 5, 0f, Pal.ORANGE)
                for (k in 0 until 3) Draw.star(c, l + 60f * s + k * 80f * s, t + 70f * s, 32f * s, 14f * s, 5, 0f, if (k < st) Pal.GOLD else 0xFF3A4A3A.toInt())
                Draw.coin(c, l + 50f * s, t + 186f * s, 22f * s)
                txt(c, fa(m.reward), l + 90f * s, t + 186f * s, 36f * s, Pal.GOLD, Paint.Align.LEFT)
                hits.add(Hit("m$i", l, max(t, top), r, min(t + ch, bottom)))
            } else {
                Draw.lock(c, W / 2f, t + ch * 0.4f, 70f * s, Pal.GRAY)
                txt(c, "ابتدا مأموریت قبلی", W / 2f, t + ch * 0.8f, 36f * s, Pal.GRAY)
            }
        }
        c.restore()
        btn(c, "barracks", W * 0.2f, H - 160f * s, W * 0.8f, H - 40f * s, "سربازخانه", Pal.ORANGE, Pal.ORANGE_D, 50f * s)
    }

    // ------------------------------------------------------------ شبکه‌ی نقش‌ها
    private fun filterChips(c: Canvas, cy: Float) {
        val names = arrayOf("همه", "پیاده", "خودرو", "پشتیبانی")
        for (i in 0..3) chip(c, "f$i", W * (0.14f + 0.24f * i + 0.0f), cy, 230f * s, names[i], filter == i)
    }

    private fun roleGrid(c: Canvas, top: Float, bottom: Float, ids: List<Int>, barracks: Boolean) {
        val cols = 3
        val gap = 20f * s
        val cw = (W - gap * (cols + 1)) / cols
        val chh = 300f * s
        val rows = ceil(ids.size / cols.toFloat()).toInt()
        val total = rows * (chh + gap) + gap
        scrL = 0f; scrT = top; scrR = W; scrB = bottom; hasScroll = true
        scrollMax = max(0f, total - (bottom - top))
        scrollY = scrollY.coerceIn(0f, scrollMax)
        c.save()
        c.clipRect(0f, top, W, bottom)
        val pl = store.playerLevel()
        for ((n, id) in ids.withIndex()) {
            val r = Roles.byId(id)
            val row = n / cols
            val col = n % cols
            val l = gap + col * (cw + gap)
            val t = top + gap + row * (chh + gap) - scrollY
            if (t > bottom || t + chh < top) continue
            val own = store.owned(id)
            val lockedLv = pl < r.unlock
            val sel = barracks && selRole == id
            Draw.rect(c, l, t, l + cw, t + chh, 24f * s, if (own) 0xDD132016.toInt() else 0xDD1A1A1A.toInt())
            Draw.frame(c, l, t, l + cw, t + chh, 24f * s, if (sel) Pal.GOLD else withAlpha(clsColor(r), if (own) 200 else 70), if (sel) 7f * s else 3f * s)
            val cx = l + cw / 2f
            Draw.circle(c, cx, t + 112f * s, 80f * s, withAlpha(Pal.WHITE, if (own) 22 else 10))
            c.save()
            if (!own) { /* تیره */ }
            Gfx.portrait(c, r, cx, t + 112f * s, 150f * s, 0, tAll)
            c.restore()
            if (!own) Draw.circle(c, cx, t + 112f * s, 80f * s, 0x99000000.toInt())
            txt(c, r.name, cx, t + 214f * s, Draw.fit(r.name, 34f * s, cw - 16f * s), if (own) Pal.CREAM else Pal.GRAY)
            if (barracks) {
                if (!own) {
                    if (lockedLv) txt(c, "سطح ${fa(r.unlock)}", cx, t + 262f * s, 32f * s, Pal.RED)
                    else {
                        Draw.coin(c, cx - 50f * s, t + 262f * s, 18f * s)
                        txt(c, fa(r.price), cx + 20f * s, t + 262f * s, 34f * s, Pal.GOLD)
                    }
                } else txt(c, "سطح ${fa(store.level(id))} · هزینه ${fa(r.cost)}", cx, t + 262f * s, Draw.fit("سطح ${fa(store.level(id))} · هزینه ${fa(r.cost)}", 30f * s, cw - 12f * s), Pal.GOLD)
            } else {
                txt(c, "هزینه ${fa(r.cost)} · سطح ${fa(store.level(id))}", cx, t + 262f * s, Draw.fit("هزینه ${fa(r.cost)} · سطح ${fa(store.level(id))}", 30f * s, cw - 12f * s), Pal.GOLD)
                val k = squad.count { it == id }
                if (k > 0) {
                    Draw.circle(c, l + 40f * s, t + 40f * s, 30f * s, Pal.GREEN_D)
                    txt(c, "×" + fa(k), l + 40f * s, t + 40f * s, 30f * s, Pal.WHITE)
                }
            }
            hits.add(Hit("r$id", l, max(t, top), l + cw, min(t + chh, bottom)))
        }
        c.restore()
    }

    // ------------------------------------------------------------ آماده‌سازی نیرو
    private fun drawLoadout(c: Canvas) {
        bg(c)
        val m = Missions.all[curMission]
        backButton(c)
        txt(c, "مأموریت ${fa(curMission + 1)}: ${m.name}", W / 2f + 120f * s, topPad + 46f * s, Draw.fit("مأموریت ${fa(curMission + 1)}: ${m.name}", 54f * s, W - 560f * s), Pal.CREAM)
        txt(c, m.brief, W / 2f, topPad + 140f * s, Draw.fit(m.brief, 34f * s, W - 60f * s), Pal.GOLD)
        txt(c, "نوع: ${Missions.typeNames[m.type]} · محیط: ${Missions.themeNames[m.theme]}", W / 2f, topPad + 190f * s, 32f * s, Pal.CREAM)
        // اسلات‌های اعزام
        val sy = topPad + 240f * s
        val cw = (W - 40f * s) / 7f
        for (i in 0 until 14) {
            val col = i % 7
            val row = i / 7
            val l = 20f * s + col * cw
            val t = sy + row * (cw + 6f * s)
            Draw.rect(c, l + 4f * s, t, l + cw - 4f * s, t + cw, 18f * s, 0xAA10190F.toInt())
            Draw.frame(c, l + 4f * s, t, l + cw - 4f * s, t + cw, 18f * s, withAlpha(Pal.WHITE, 40), 2f * s)
            if (i < squad.size) {
                val r = Roles.byId(squad[i])
                Gfx.portrait(c, r, l + cw / 2f, t + cw / 2f, cw * 0.8f, 0, tAll)
                hits.add(Hit("sq$i", l, t, l + cw, t + cw))
            }
        }
        val used = squadCost()
        val bud = store.budget()
        val by = sy + 2f * (cw + 6f * s) + 40f * s
        Draw.rect(c, 40f * s, by - 20f * s, W - 40f * s, by + 20f * s, 20f * s, 0xAA10190F.toInt())
        Draw.rect(c, 40f * s, by - 20f * s, 40f * s + (W - 80f * s) * min(1f, used / bud.toFloat()), by + 20f * s, 20f * s, if (used > bud) Pal.RED else Pal.GREEN)
        txt(c, "بودجه: ${fa(used)} از ${fa(bud)}", W / 2f, by, 30f * s, Pal.WHITE, )
        filterChips(c, by + 80f * s)
        val gtop = by + 130f * s
        val gbot = H - 220f * s
        roleGrid(c, gtop, gbot, filtered(true), false)
        btn(c, "clear", 28f * s, H - 200f * s, W * 0.27f, H - 70f * s, "خالی", Pal.GRAY, Pal.GRAY_D, 38f * s)
        btn(c, "auto", W * 0.29f, H - 200f * s, W * 0.5f, H - 70f * s, "خودکار", 0xFF3F6FA8.toInt(), 0xFF264A78.toInt(), 38f * s)
        btn(c, "start", W * 0.52f, H - 200f * s, W - 28f * s, H - 70f * s, "اعزام به نبرد", Pal.GREEN, Pal.GREEN_D, 50f * s)
    }

    // ------------------------------------------------------------ سربازخانه
    private fun statLine(c: Canvas, label: String, v: String, x: Float, y: Float) {
        txt(c, label, x, y, 30f * s, Pal.GRAY, Paint.Align.RIGHT)
        txt(c, v, x - 150f * s, y, 32f * s, Pal.CREAM, Paint.Align.RIGHT)
    }

    private fun drawBarracks(c: Canvas) {
        bg(c)
        backButton(c)
        coinPill(c, W - 28f * s, topPad + 46f * s)
        txt(c, "سربازخانه", W / 2f + 60f * s, topPad + 150f * s, 70f * s, Pal.CREAM)
        txt(c, "سطح فرمانده ${fa(store.playerLevel())}", W / 2f, topPad + 215f * s, 32f * s, Pal.GOLD)
        filterChips(c, topPad + 285f * s)
        val gtop = topPad + 340f * s
        val dh = 560f * s
        val gbot = H - dh - 20f * s
        roleGrid(c, gtop, gbot, filtered(false), true)
        // جزئیات
        val r = Roles.byId(selRole)
        val t = H - dh
        panel(c, 16f * s, t, W - 16f * s, H - 16f * s)
        Draw.circle(c, 190f * s, t + 170f * s, 120f * s, withAlpha(Pal.WHITE, 22))
        Gfx.portrait(c, r, 190f * s, t + 170f * s, 220f * s, 0, tAll)
        txt(c, r.name, W - 60f * s, t + 56f * s, 54f * s, Pal.CREAM, Paint.Align.RIGHT)
        txt(c, r.cls + " · " + r.desc, W - 60f * s, t + 116f * s, Draw.fit(r.cls + " · " + r.desc, 30f * s, W - 400f * s), Pal.GOLD, Paint.Align.RIGHT)
        val lv = store.level(r.id)
        val mu = Roles.mult(lv)
        if (r.kind != 2) {
            statLine(c, "جان", fa((r.hp * mu).toInt()), W - 60f * s, t + 180f * s)
            statLine(c, "قدرت", fa((r.dmg * mu).toInt()) + (if (r.splash > 0f) " (انفجاری)" else ""), W - 60f * s, t + 226f * s)
            statLine(c, "برد", fa(r.range.toInt()), W - 60f * s, t + 272f * s)
            statLine(c, "زره", fa((r.armor * 100).toInt()) + "٪", W - 400f * s, t + 180f * s)
            statLine(c, "سرعت", fa((r.speed * 10).toInt()), W - 400f * s, t + 226f * s)
            statLine(c, "ضدزره", fa((r.at * 100).toInt()) + "٪", W - 400f * s, t + 272f * s)
        } else txt(c, "کارت پشتیبانی · شارژ مجدد ${fa(r.cd.toInt())} ثانیه", W - 60f * s, t + 200f * s, 34f * s, Pal.CREAM, Paint.Align.RIGHT)
        if (r.ab != Ab.NONE) {
            val line = "توانایی: " + Ab.names[r.ab] + " — " + Ab.descs[r.ab]
            txt(c, line, W / 2f, t + 330f * s, Draw.fit(line, 30f * s, W - 80f * s), Pal.ORANGE)
        }
        txt(c, "سطح ${fa(lv)} از ۱۰ · هزینه‌ی اعزام ${fa(r.cost)}", W / 2f, t + 385f * s, 32f * s, Pal.CREAM)
        if (!store.owned(r.id)) {
            val can = store.playerLevel() >= r.unlock
            btn(c, "buy", W * 0.15f, t + 420f * s, W * 0.85f, t + 530f * s,
                if (can) "خرید  ·  ${fa(r.price)} سکه" else "نیازمند سطح فرمانده ${fa(r.unlock)}", Pal.GREEN, Pal.GREEN_D, 44f * s, can)
        } else {
            btn(c, "up", W * 0.15f, t + 420f * s, W * 0.85f, t + 530f * s,
                if (lv >= 10) "بالاترین سطح" else "ارتقا  ·  ${fa(upCost(r))} سکه", Pal.ORANGE, Pal.ORANGE_D, 44f * s, lv < 10)
        }
    }

    // ------------------------------------------------------------ نبرد
    private fun drawBattle(c: Canvas) {
        val b = battle ?: return
        c.drawColor(0xFF10160F.toInt())
        // جهان
        c.save()
        c.clipRect(0f, 0f, W, vh)
        val sx = if (shake > 0f) (rnd.nextFloat() - 0.5f) * shake * 24f * s else 0f
        val sy = if (shake > 0f) (rnd.nextFloat() - 0.5f) * shake * 24f * s else 0f
        c.translate(W / 2f - camX * ppt + sx, vh / 2f - camY * ppt + sy)
        c.scale(ppt, ppt)
        val bmp = terrain
        if (bmp != null) c.drawBitmap(bmp, null, RectF(0f, 0f, b.cols.toFloat(), b.rows.toFloat()), null)
        Gfx.groundFx(c, b, tAll)
        // مرز نقشه
        Draw.frame(c, 0f, 0f, b.cols.toFloat(), b.rows.toFloat(), 0f, 0xFF000000.toInt(), 0.2f)
        val hw = vw / ppt / 2f + 2f
        val hh = vh / ppt / 2f + 2f
        for (m in b.mobs) if (m.dead && abs(m.x - camX) < hw && abs(m.y - camY) < hh) Gfx.mob(c, m, tAll)
        for (pass in 0..1) {
            for (m in b.mobs) {
                if (m.dead) continue
                if ((m.role.kind == 0) != (pass == 0)) continue
                if (abs(m.x - camX) > hw || abs(m.y - camY) > hh) continue
                if (m.team == 1 && !seen.contains(m.id)) continue
                Gfx.mob(c, m, tAll)
            }
        }
        // انتخاب خط مقصد
        for (m in squadMobs) {
            if (m.dead || !m.selected || !m.hasGoal) continue
            val gi = m.path.size - 1
            if (gi >= 0 && m.pi <= gi) {
                val gx = (m.path[gi] % b.cols) + 0.5f
                val gy = (m.path[gi] / b.cols) + 0.5f
                Draw.line(c, m.x, m.y, gx, gy, withAlpha(Pal.GREEN, 70), 0.04f)
                Draw.ring(c, gx, gy, 0.22f, withAlpha(Pal.GREEN, 160), 0.05f)
            }
        }
        Gfx.airFx(c, b, tAll)
        for (mk in marks) {
            val k = mk.age / 0.8f
            Draw.ring(c, mk.x, mk.y, 0.6f * (1f - k) + 0.1f, withAlpha(Pal.WHITE, (230 * (1f - k)).toInt()), 0.06f)
        }
        // محدوده‌ی هدف‌گیری
        val am = aimMob
        if (am != null) {
            val rg = Roles.abRange(am.role)
            if (rg in 0.5f..49f) {
                Draw.circle(c, am.x, am.y, rg, withAlpha(Pal.GOLD, 28))
                Draw.ring(c, am.x, am.y, rg, withAlpha(Pal.GOLD, 200), 0.06f)
            }
        }
        for (f in ftexts) {
            val col = when (f.color) { 1 -> Pal.RED; 3 -> Pal.GREEN; 4 -> Pal.GOLD; else -> Pal.WHITE }
            Draw.text(c, f.text, f.x, f.y - 0.8f - f.age * 0.9f, 0.5f, withAlpha(col, (255 * (1f - f.age / 1.4f)).toInt()), 0x99000000.toInt())
        }
        c.restore()
        drawHud(c, b)
        drawPanel(c, b)
        if (paused) drawPause(c)
    }

    private fun drawHud(c: Canvas, b: Battle) {
        // نوار بالا
        Draw.rect(c, 0f, 0f, W, topPad + 110f * s, 0f, withAlpha(black, 120))
        btn(c, "pause", 20f * s, topPad - 10f * s, 140f * s, topPad + 92f * s, "||", 0xFF3F6FA8.toInt(), 0xFF264A78.toInt(), 54f * s)
        btn(c, "speed", W - 160f * s, topPad - 10f * s, W - 20f * s, topPad + 92f * s, if (speed > 1f) "۲×" else "۱×", Pal.ORANGE, Pal.ORANGE_D, 48f * s)
        txt(c, b.objectiveText(), W / 2f, topPad + 28f * s, Draw.fit(b.objectiveText(), 44f * s, W - 360f * s), Pal.CREAM)
        val rem = b.players().size
        txt(c, "نیروها ${fa(rem)} از ${fa(b.startCount)}  ·  کشته ${fa(b.killCount)}", W / 2f, topPad + 78f * s, 32f * s, Pal.GOLD)
        // دکمه‌های کناری
        btn(c, "all", 20f * s, topPad + 130f * s, 210f * s, topPad + 220f * s, "همه", Pal.GREEN, Pal.GREEN_D, 38f * s)
        btn(c, "center", 20f * s, topPad + 240f * s, 210f * s, topPad + 330f * s, "مرکز", Pal.BLUE, Pal.BLUE_D, 38f * s)
        // مینی‌مپ
        miniW = 150f * s
        miniH = miniW * b.rows / b.cols
        miniL = W - miniW - 20f * s
        miniT = topPad + 130f * s
        Draw.rect(c, miniL - 6f * s, miniT - 6f * s, miniL + miniW + 6f * s, miniT + miniH + 6f * s, 10f * s, withAlpha(black, 170))
        val bmp = terrain
        if (bmp != null) c.drawBitmap(bmp, null, RectF(miniL, miniT, miniL + miniW, miniT + miniH), null)
        val k = miniW / b.cols
        for (z in b.zones) Draw.ring(c, miniL + z.cx * k, miniT + z.cy * k, z.r * k, if (z.prog >= 1f) Pal.GREEN else Pal.GOLD, 3f * s)
        for (m in b.mobs) {
            if (m.dead) continue
            if (m.team == 1 && !seen.contains(m.id)) continue
            Draw.circle(c, miniL + m.x * k, miniT + m.y * k, 4.5f * s, if (m.team == 0) Pal.GREEN else Pal.RED)
        }
        val vwTiles = vw / ppt
        val vhTiles = vh / ppt
        Draw.frame(c, miniL + (camX - vwTiles / 2f) * k, miniT + (camY - vhTiles / 2f) * k, miniL + (camX + vwTiles / 2f) * k, miniT + (camY + vhTiles / 2f) * k, 0f, Pal.WHITE, 2f * s)
        hits.add(Hit("mini", miniL, miniT, miniL + miniW, miniT + miniH))
        // راهنما
        if (helpT > 0f && b.state == 0) {
            val a = min(1f, helpT)
            val lines = arrayOf("روی زمین بزنید تا نیروهای انتخاب‌شده حرکت کنند", "روی دشمن بزنید تا حمله کنند · با کشیدن نقشه را جابه‌جا کنید", "دایره‌ی کنار هر نیرو، توانایی ویژه‌ی اوست")
            Draw.rect(c, 60f * s, vh - 260f * s, W - 60f * s, vh - 40f * s, 24f * s, withAlpha(black, (170 * a).toInt()))
            for (i in lines.indices) txt(c, lines[i], W / 2f, vh - 215f * s + i * 60f * s, Draw.fit(lines[i], 34f * s, W - 160f * s), withAlpha(Pal.CREAM, (255 * a).toInt()))
        }
        if (aimMob != null || aimCard != null) {
            Draw.rect(c, 40f * s, topPad + 350f * s, W - 40f * s, topPad + 440f * s, 22f * s, withAlpha(0xFF3A2A00.toInt(), 220))
            txt(c, "هدف را روی نقشه بزنید", W / 2f + 100f * s, topPad + 395f * s, 38f * s, Pal.GOLD)
            btn(c, "cancel", 60f * s, topPad + 358f * s, 250f * s, topPad + 436f * s, "لغو", Pal.RED, Pal.RED_D, 34f * s)
        }
        if (b.state != 0) {
            val a = min(1f, b.endT * 2f)
            txt(c, if (b.state == 1) "پیروزی!" else "شکست", W / 2f, vh * 0.4f, 150f * s, withAlpha(if (b.state == 1) Pal.GOLD else Pal.RED, (255 * a).toInt()))
        }
    }

    private fun drawPanel(c: Canvas, b: Battle) {
        val top = vh
        Draw.rect(c, 0f, top, W, H, 0f, 0xFF0C140E.toInt())
        Draw.rect(c, 0f, top, W, top + 5f * s, 0f, 0xFF3C5A3C.toInt())
        val cw = (W - 40f * s) / 7f
        val chh = 170f * s
        val total = squadMobs.size + b.cards.size
        for (i in 0 until total) {
            val col = i % 7
            val row = i / 7
            val l = 20f * s + col * cw
            val t = top + 14f * s + row * chh
            if (i < squadMobs.size) {
                val m = squadMobs[i]
                val dead = m.dead
                Draw.rect(c, l + 4f * s, t, l + cw - 4f * s, t + chh - 8f * s, 16f * s, if (m.selected && !dead) 0xFF2B4A2B.toInt() else 0xFF161F18.toInt())
                Draw.frame(c, l + 4f * s, t, l + cw - 4f * s, t + chh - 8f * s, 16f * s, if (m.selected && !dead) Pal.GOLD else withAlpha(Pal.WHITE, 40), if (m.selected && !dead) 4f * s else 2f * s)
                Gfx.portrait(c, m.role, l + cw / 2f, t + 62f * s, cw * 0.72f, 0, tAll)
                if (dead) {
                    Draw.rect(c, l + 4f * s, t, l + cw - 4f * s, t + chh - 8f * s, 16f * s, 0xAA000000.toInt())
                    Draw.line(c, l + cw * 0.3f, t + 40f * s, l + cw * 0.7f, t + 84f * s, Pal.RED, 8f * s); Draw.line(c, l + cw * 0.7f, t + 40f * s, l + cw * 0.3f, t + 84f * s, Pal.RED, 8f * s)
                } else {
                    val hp = (m.hp / m.maxHp).coerceIn(0f, 1f)
                    Draw.rect(c, l + 14f * s, t + 122f * s, l + cw - 14f * s, t + 140f * s, 6f * s, 0xFF000000.toInt())
                    Draw.rect(c, l + 14f * s, t + 122f * s, l + 14f * s + (cw - 28f * s) * hp, t + 140f * s, 6f * s, if (hp > 0.5f) Pal.GREEN else if (hp > 0.25f) Pal.GOLD else Pal.RED)
                    hits.add(Hit("u$i", l, t, l + cw, t + chh - 8f * s))
                    if (m.role.ab != Ab.NONE) {
                        val ax = l + cw - 28f * s
                        val ay = t + 28f * s
                        val ready = m.abT <= 0f
                        Draw.circle(c, ax, ay, 24f * s, if (aimMob === m) Pal.GOLD else if (ready) Pal.ORANGE else 0xFF333333.toInt())
                        if (!ready) Draw.arc(c, ax, ay, 24f * s, -90f, 360f * (1f - m.abT / m.role.cd), Pal.ORANGE_D, 8f * s)
                        Draw.star(c, ax, ay, 15f * s, 7f * s, 5, 0f, Pal.WHITE)
                        hits.add(Hit("a$i", ax - 34f * s, ay - 34f * s, ax + 34f * s, ay + 34f * s))
                    }
                }
            } else {
                val ci = i - squadMobs.size
                val cd = b.cards[ci]
                val ready = cd.cd <= 0f
                Draw.rect(c, l + 4f * s, t, l + cw - 4f * s, t + chh - 8f * s, 16f * s, 0xFF1B2540.toInt())
                Draw.frame(c, l + 4f * s, t, l + cw - 4f * s, t + chh - 8f * s, 16f * s, if (aimCard === cd) Pal.GOLD else Pal.BLUE, 3f * s)
                Gfx.portrait(c, cd.role, l + cw / 2f, t + 62f * s, cw * 0.72f, 0, tAll)
                if (!ready) {
                    Draw.rect(c, l + 4f * s, t, l + cw - 4f * s, t + chh - 8f * s, 16f * s, 0xAA000000.toInt())
                    txt(c, fa(ceil(cd.cd).toInt()), l + cw / 2f, t + 62f * s, 46f * s, Pal.WHITE)
                }
                txt(c, cd.role.name, l + cw / 2f, t + 130f * s, Draw.fit(cd.role.name, 24f * s, cw - 12f * s), Pal.CREAM)
                hits.add(Hit("c$ci", l, t, l + cw, t + chh - 8f * s))
            }
        }
    }

    private fun drawPause(c: Canvas) {
        c.drawColor(0xAA000000.toInt())
        panel(c, 90f * s, H * 0.3f, W - 90f * s, H * 0.3f + 700f * s)
        txt(c, "توقف", W / 2f, H * 0.3f + 90f * s, 80f * s, Pal.CREAM)
        btn(c, "resume", 150f * s, H * 0.3f + 170f * s, W - 150f * s, H * 0.3f + 300f * s, "ادامه", Pal.GREEN, Pal.GREEN_D, 56f * s)
        btn(c, "quit", 150f * s, H * 0.3f + 330f * s, W - 150f * s, H * 0.3f + 460f * s, "بازگشت به نقشه", Pal.RED, Pal.RED_D, 48f * s)
        chip(c, "music", W * 0.34f, H * 0.3f + 580f * s, 320f * s, if (store.music) "موسیقی: روشن" else "موسیقی: خاموش", store.music)
        chip(c, "sfxb", W * 0.68f, H * 0.3f + 580f * s, 320f * s, if (store.sfx) "صدا: روشن" else "صدا: خاموش", store.sfx)
    }

    // ------------------------------------------------------------ نتیجه
    private fun drawResult(c: Canvas) {
        bg(c)
        val m = Missions.all[curMission]
        txt(c, if (resWin) "پیروزی!" else "شکست", W / 2f, H * 0.12f, 150f * s, if (resWin) Pal.GOLD else Pal.RED)
        txt(c, m.name, W / 2f, H * 0.12f + 130f * s, 56f * s, Pal.CREAM)
        for (k in 0 until 3) {
            val sh = resT > 0.4f + k * 0.4f
            val sz = if (sh && k < resStars) 90f * s * min(1f, (resT - 0.4f - k * 0.4f) * 5f).coerceAtLeast(0.2f) else 80f * s
            Draw.star(c, W / 2f + (k - 1) * 230f * s, H * 0.3f, sz, sz * 0.45f, 5, 0f, if (k < resStars && sh) Pal.GOLD else 0xFF334033.toInt())
        }
        panel(c, 90f * s, H * 0.4f, W - 90f * s, H * 0.4f + 480f * s)
        txt(c, "دشمن‌های نابودشده: ${fa(resKills)}", W / 2f, H * 0.4f + 70f * s, 44f * s, Pal.CREAM)
        txt(c, "تلفات ما: ${fa(resLost)}", W / 2f, H * 0.4f + 140f * s, 44f * s, Pal.CREAM)
        Draw.coin(c, W / 2f - 150f * s, H * 0.4f + 230f * s, 36f * s)
        val shown = (resCoins * min(1f, resT / 1.4f)).toInt()
        txt(c, "+" + fa(shown), W / 2f + 30f * s, H * 0.4f + 230f * s, 70f * s, Pal.GOLD)
        if (resNew.isNotEmpty()) txt(c, resNew, W / 2f, H * 0.4f + 340f * s, Draw.fit(resNew, 34f * s, W - 220f * s), Pal.GREEN)
        else if (!resWin) txt(c, "نیروها را در سربازخانه ارتقا دهید و دوباره تلاش کنید", W / 2f, H * 0.4f + 340f * s, Draw.fit("نیروها را در سربازخانه ارتقا دهید و دوباره تلاش کنید", 34f * s, W - 220f * s), Pal.GOLD)
        val y = H * 0.4f + 540f * s
        if (resWin && curMission < Missions.all.size - 1) btn(c, "next", W * 0.12f, y, W * 0.88f, y + 130f * s, "مأموریت بعدی", Pal.GREEN, Pal.GREEN_D, 54f * s)
        btn(c, "again", W * 0.12f, y + 160f * s, W * 0.5f - 10f * s, y + 280f * s, "دوباره", Pal.ORANGE, Pal.ORANGE_D, 46f * s)
        btn(c, "camp", W * 0.5f + 10f * s, y + 160f * s, W * 0.88f, y + 280f * s, "نقشه", 0xFF3F6FA8.toInt(), 0xFF264A78.toInt(), 46f * s)
    }

    // ------------------------------------------------------------ راهنما و درباره
    private fun drawAbout(c: Canvas) {
        bg(c)
        backButton(c)
        txt(c, "راهنما و درباره", W / 2f + 80f * s, topPad + 150f * s, 66f * s, Pal.CREAM)
        panel(c, 40f * s, topPad + 230f * s, W - 40f * s, H - 220f * s)
        val lines = arrayOf(
            "• روی زمین بزنید تا نیروهای انتخاب‌شده به آنجا بروند.",
            "• روی دشمن بزنید تا همه به او حمله کنند.",
            "• با کشیدن انگشت، نقشه را جابه‌جا کنید.",
            "• کارت پایین صفحه را انتخاب کنید و سپس روی نقشه بزنید.",
            "• ستاره‌ی کنار هر نیرو، توانایی ویژه‌ی اوست.",
            "• جنگل پنهان می‌کند، دیوار جلوی تیر را می‌گیرد،",
            "   کیسه‌ی شن آسیب را کم می‌کند و دود دید را می‌بندد.",
            "• تیرانداز و خمپاره‌انداز دور را می‌زنند؛ تانک را با",
            "   بازوکا و ضدتانک بزنید، نه با تفنگ.",
            "• با هر مأموریت، سکه می‌گیرید؛ در سربازخانه",
            "   نقش جدید بخرید و نیروها را ارتقا دهید.",
            "• بودجه‌ی اعزام با پیشروی بیشتر می‌شود."
        )
        for (i in lines.indices) txt(c, lines[i], W - 80f * s, topPad + 300f * s + i * 62f * s, Draw.fit(lines[i], 33f * s, W - 160f * s), Pal.CREAM, Paint.Align.RIGHT)
        txt(c, "طراح و سازنده: شاهین شیخ کانلو", W / 2f, H - 130f * s, 42f * s, Pal.GOLD)
        txt(c, "خط مقدم", W / 2f, H - 70f * s, 30f * s, withAlpha(Pal.CREAM, 160))
    }
}
