package ir.shahin.frontline

import android.content.Context
import android.content.SharedPreferences
import java.util.Random
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** ذخیره‌ی پیشرفت */
class Store(ctx: Context) {
    private val p: SharedPreferences = ctx.getSharedPreferences("frontline", Context.MODE_PRIVATE)

    var coins: Int
        get() = p.getInt("coins", 300)
        set(v) {
            p.edit().putInt("coins", max(0, v)).apply()
        }

    var sfx: Boolean
        get() = p.getBoolean("sfx", true)
        set(v) {
            p.edit().putBoolean("sfx", v).apply()
        }

    var music: Boolean
        get() = p.getBoolean("music", true)
        set(v) {
            p.edit().putBoolean("music", v).apply()
        }

    fun owned(id: Int): Boolean = id == 0 || p.getBoolean("own_$id", false)
    fun setOwned(id: Int) {
        p.edit().putBoolean("own_$id", true).apply()
    }

    fun level(id: Int): Int = p.getInt("lv_$id", 1).coerceIn(1, 10)
    fun setLevel(id: Int, v: Int) {
        p.edit().putInt("lv_$id", v.coerceIn(1, 10)).apply()
    }

    fun stars(i: Int): Int = p.getInt("st_$i", 0)
    fun setStars(i: Int, v: Int) {
        if (v > stars(i)) p.edit().putInt("st_$i", v).apply()
    }

    var kills: Int
        get() = p.getInt("kills", 0)
        set(v) {
            p.edit().putInt("kills", v).apply()
        }

    /** تعداد مأموریت‌های تمام‌شده */
    fun cleared(): Int {
        var n = 0
        for (i in Missions.all.indices) if (stars(i) > 0) n++
        return n
    }

    /** سطح فرمانده: با هر مأموریت یک سطح بالا می‌رود */
    fun playerLevel(): Int = 1 + cleared()

    /** بودجه‌ی اعزام */
    fun budget(): Int = min(150, 60 + 8 * cleared())

    var squadText: String
        get() = p.getString("squad", "0,0,0,0") ?: "0,0,0,0"
        set(v) {
            p.edit().putString("squad", v).apply()
        }

    fun squad(): ArrayList<Int> {
        val l = ArrayList<Int>()
        for (s in squadText.split(",")) {
            val v = s.trim().toIntOrNull() ?: continue
            if (v in 0 until Roles.all.size && owned(v)) l.add(v)
        }
        return l
    }

    fun saveSquad(l: List<Int>) {
        squadText = l.joinToString(",")
    }
}

/** مأموریت. type: ۰ نابودی دشمن، ۱ تصرف نقاط، ۲ مقاومت تا پایان زمان، ۳ یورش به سنگرها */
class Mission(
    val id: Int, val name: String, val brief: String, val theme: Int, val type: Int, val diff: Int,
    val seed: Int, val river: Boolean, val zones: Int, val bunkers: Int, val enemies: Int,
    val waves: Int, val time: Float, val reward: Int
)

object Missions {
    val typeNames = arrayOf("نابودی دشمن", "تصرف نقاط", "مقاومت", "یورش به سنگرها")
    val themeNames = arrayOf("دشت", "روستا", "برف", "صحرا", "شهر ویران")

    val all: List<Mission> = listOf(
        Mission(0, "سپیده‌دم", "اولین برخورد در دشت. دشمن را از منطقه بیرون کنید.", 0, 0, 0, 11, false, 0, 0, 7, 0, 0f, 80),
        Mission(1, "پل شکسته", "پل را بگیرید و نقطه‌ی فرماندهی کنار آن را تصرف کنید.", 0, 1, 1, 23, true, 1, 0, 8, 1, 0f, 110),
        Mission(2, "روستای بی‌صدا", "دشمن در خانه‌های روستا سنگر گرفته است.", 1, 0, 1, 37, false, 0, 0, 10, 1, 0f, 130),
        Mission(3, "جنگل مه", "حمله‌های موج‌به‌موج را تا رسیدن نیروی کمکی تاب بیاورید.", 2, 2, 2, 41, false, 0, 0, 4, 0, 90f, 150),
        Mission(4, "تپه‌ی ۱۰۴", "سنگرهای مسلسل و ضدتانک را نابود کنید.", 0, 3, 2, 53, false, 0, 3, 9, 1, 0f, 180),
        Mission(5, "عبور از رود", "دو نقطه‌ی کنار رودخانه را تصرف کنید.", 1, 1, 3, 67, true, 2, 0, 11, 2, 0f, 210),
        Mission(6, "قلب شهر", "نبرد خیابانی؛ هر ساختمان یک سنگر است.", 4, 0, 3, 71, false, 0, 0, 14, 2, 0f, 240),
        Mission(7, "شب طوفانی", "برف و باد؛ تا طلوع دوام بیاورید.", 2, 2, 4, 83, false, 0, 0, 5, 0, 120f, 280),
        Mission(8, "دره‌ی آتش", "سنگرهای دشمن در صحرا را درهم بشکنید.", 3, 3, 4, 97, true, 0, 4, 12, 2, 0f, 320),
        Mission(9, "خط آهن", "سه ایستگاه را پشت‌سرهم تصرف کنید.", 3, 1, 5, 101, false, 3, 0, 13, 2, 0f, 360),
        Mission(10, "یورش بزرگ", "سنگین‌ترین دفاع دشمن در شهر ویران.", 4, 3, 6, 113, true, 0, 5, 16, 3, 0f, 420),
        Mission(11, "پایان جبهه", "آخرین هجوم دشمن؛ زره‌پوش‌های سنگین در راهند.", 2, 2, 7, 127, false, 0, 0, 6, 0, 150f, 600)
    )
}

class GameMap(val cols: Int, val rows: Int, val t: ByteArray, val theme: Int) {
    val zones = ArrayList<FloatArray>()
    val bunkers = ArrayList<FloatArray>()
    var startX = cols / 2f
    var startY = rows - 3f
    fun at(x: Int, y: Int): Int = if (x < 0 || y < 0 || x >= cols || y >= rows) 4 else t[y * cols + x].toInt()
}

/**
 * انواع زمین: ۰ چمن، ۱ جاده، ۲ آب، ۳ جنگل، ۴ ساختمان، ۵ کیسه‌ی شن، ۶ آوار، ۸ پل
 */
object MapGen {
    const val COLS = 18
    const val ROWS = 32

    fun generate(m: Mission): GameMap {
        val rnd = Random(m.seed * 7919L + m.theme)
        val t = ByteArray(COLS * ROWS)
        val map = GameMap(COLS, ROWS, t, m.theme)
        fun set(x: Int, y: Int, v: Int) {
            if (x in 0 until COLS && y in 0 until ROWS) t[y * COLS + x] = v.toByte()
        }
        fun get(x: Int, y: Int): Int = map.at(x, y)

        // جاده‌ی اصلی از پایین تا بالا
        val roadX = IntArray(ROWS)
        var x = COLS / 2f
        for (y in ROWS - 1 downTo 0) {
            x += (rnd.nextFloat() - 0.5f) * 0.9f
            x = x.coerceIn(4f, COLS - 6f)
            roadX[y] = x.toInt()
            set(roadX[y], y, 1)
            set(roadX[y] + 1, y, 1)
        }
        // رودخانه با پل روی جاده
        var riverY = -1
        if (m.river) {
            riverY = (ROWS * 0.45f).toInt() + rnd.nextInt(4) - 2
            for (xx in 0 until COLS) {
                val wob = ((Math.sin(xx * 0.7 + m.seed) * 0.8).toInt())
                for (k in 0..2) {
                    val yy = riverY + wob + k
                    if (get(xx, yy) == 1) set(xx, yy, 8) else set(xx, yy, 2)
                }
            }
            // پل با کل عرض جاده
            for (yy in riverY - 2..riverY + 5) {
                if (yy in 0 until ROWS) {
                    for (dx in 0..1) if (get(roadX[yy] + dx, yy) == 2) set(roadX[yy] + dx, yy, 8)
                }
            }
        }
        fun nearRoad(cx: Int, cy: Int, d: Int): Boolean {
            for (yy in cy - d..cy + d) for (xx in cx - d..cx + d) {
                val v = get(xx, yy)
                if (v == 1 || v == 8) return true
            }
            return false
        }
        fun inStartArea(cy: Int) = cy >= ROWS - 6
        fun inSpawnArea(cy: Int) = cy <= 2

        // جنگل
        val forests = when (m.theme) {
            2 -> 9
            1 -> 5
            3 -> 3
            4 -> 3
            else -> 6
        }
        for (i in 0 until forests) {
            val cx = rnd.nextInt(COLS)
            val cy = 4 + rnd.nextInt(ROWS - 10)
            val r = 2 + rnd.nextInt(3)
            for (yy in cy - r..cy + r) for (xx in cx - r..cx + r) {
                if ((xx - cx) * (xx - cx) + (yy - cy) * (yy - cy) <= r * r && get(xx, yy) == 0 && !nearRoad(xx, yy, 1) &&
                    !inStartArea(yy) && !inSpawnArea(yy)
                ) set(xx, yy, 3)
            }
        }
        // ساختمان‌ها و آوار
        val buildings = when (m.theme) {
            4 -> 16
            1 -> 12
            0 -> 3
            2 -> 4
            else -> 5
        }
        var placed = 0
        var tries = 0
        while (placed < buildings && tries < 200) {
            tries++
            val w = 2 + rnd.nextInt(2)
            val h = 2 + rnd.nextInt(2)
            val bx = 1 + rnd.nextInt(COLS - w - 1)
            val by = 4 + rnd.nextInt(ROWS - h - 10)
            var ok = true
            for (yy in by - 1..by + h) for (xx in bx - 1..bx + w) {
                if (get(xx, yy) != 0 || nearRoad(xx, yy, 1)) ok = false
            }
            if (!ok || inStartArea(by + h) || inSpawnArea(by)) continue
            for (yy in by until by + h) for (xx in bx until bx + w) set(xx, yy, 4)
            if (m.theme == 4) {
                for (k in 0 until 3) {
                    val rx = bx - 1 + rnd.nextInt(w + 2)
                    val ry = by - 1 + rnd.nextInt(h + 2)
                    if (get(rx, ry) == 0) set(rx, ry, 6)
                }
            }
            placed++
        }
        // کیسه‌ی شن
        for (i in 0 until 5) {
            val sx = 2 + rnd.nextInt(COLS - 8)
            val sy = 4 + rnd.nextInt(14)
            for (k in 0 until 3) if (get(sx + k, sy) == 0 && !nearRoad(sx + k, sy, 0)) set(sx + k, sy, 5)
        }
        // منطقه‌ی شروع پاک
        for (yy in ROWS - 6 until ROWS) for (xx in 0 until COLS) {
            val v = get(xx, yy)
            if (v != 1 && v != 8) set(xx, yy, 0)
        }
        map.startX = roadX[ROWS - 3] + 1f
        map.startY = ROWS - 3f
        // نقطه‌های تصرف
        val zyFr = when (m.zones) {
            1 -> floatArrayOf(0.30f)
            2 -> floatArrayOf(0.50f, 0.18f)
            3 -> floatArrayOf(0.62f, 0.40f, 0.16f)
            else -> floatArrayOf()
        }
        for (f in zyFr) {
            val zy = (ROWS * f).toInt()
            map.zones.add(floatArrayOf(roadX[zy] + 1f, zy + 0.5f))
            for (yy in zy - 2..zy + 2) for (xx in roadX[zy] - 2..roadX[zy] + 4) {
                if (get(xx, yy) in intArrayOf(4, 3)) set(xx, yy, 0)
            }
        }
        // جای سنگرها
        var bt = 0
        var bTries = 0
        while (bt < m.bunkers && bTries < 300) {
            bTries++
            val bx = 2 + rnd.nextInt(COLS - 4)
            val by = 3 + rnd.nextInt(12)
            if (get(bx, by) != 0) continue
            var far = true
            for (o in map.bunkers) if (abs(o[0] - bx) < 3.5f && abs(o[1] - by) < 3.5f) far = false
            if (!far) continue
            map.bunkers.add(floatArrayOf(bx + 0.5f, by + 0.5f))
            bt++
        }
        return map
    }
}
