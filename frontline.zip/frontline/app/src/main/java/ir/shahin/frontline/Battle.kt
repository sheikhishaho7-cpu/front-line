package ir.shahin.frontline

import java.util.PriorityQueue
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

const val PI_F = PI.toFloat()

class Mob(val id: Int, val role: Role, val team: Int, var x: Float, var y: Float, val lvl: Int) {
    val mult = Roles.mult(lvl)
    val maxHp = role.hp * mult
    var hp = maxHp
    var face = if (team == 0) -PI_F / 2f else PI_F / 2f
    var turret = face
    var path = IntArray(0)
    var pi = 0
    var hasGoal = false
    var cd = 0.4f
    var abT = 0f
    var target: Mob? = null
    var forced: Mob? = null
    var dead = false
    var deadT = 0f
    var camo = 0f
    var fort = 0f
    var rally = 0f
    var supp = 0f
    var burn = 0f
    var dash = 0f
    var recon = 0f
    var flash = 0f
    var hurt = 0f
    var moving = false
    var walk = 0f
    var alert = false
    var kills = 0
    var scanT = 0f
    var thinkT = 0f
    var repathT = 0f
    var flankT = 3f
    var selected = false
    var dustT = 0f
    val r: Float get() = role.size
}

class Tracer(val x1: Float, val y1: Float, val x2: Float, val y2: Float, var life: Float, val big: Boolean)
class Proj(
    var x: Float, var y: Float, val sx: Float, val sy: Float, val tx: Float, val ty: Float,
    var t: Float, val dur: Float, val dmg: Float, val splash: Float, val at: Float, val kind: Int
)

class Blast(val x: Float, val y: Float, val r: Float, var life: Float, val max: Float, val kind: Int)
class Smoke(val x: Float, val y: Float, val r: Float, var life: Float, val max: Float)
class Fire(val x: Float, val y: Float, val r: Float, var life: Float, val dps: Float)
class Mine(val x: Float, val y: Float, val team: Int, val dmg: Float, val rad: Float)
class Crater(val x: Float, val y: Float, val r: Float)
class Delay(var t: Float, val x: Float, val y: Float, val dmg: Float, val rad: Float, val at: Float, val kind: Int)
class Plane(var x: Float, var y: Float, val vx: Float, val vy: Float, var life: Float, val kind: Int)
class Zone(val cx: Float, val cy: Float, val r: Float) {
    var prog = 0f
}

class Card(val role: Role, val lvl: Int) {
    var cd = 6f
}

class Battle(val m: Mission, squadIds: List<Int>, cardIds: List<Int>, val levelOf: (Int) -> Int) {
    val map = MapGen.generate(m)
    val cols = map.cols
    val rows = map.rows
    val rnd = Random(System.nanoTime())
    val mobs = ArrayList<Mob>()
    val cards = ArrayList<Card>()
    val tracers = ArrayList<Tracer>()
    val projs = ArrayList<Proj>()
    val blasts = ArrayList<Blast>()
    val smokes = ArrayList<Smoke>()
    val fires = ArrayList<Fire>()
    val mines = ArrayList<Mine>()
    val craters = ArrayList<Crater>()
    val delays = ArrayList<Delay>()
    val planes = ArrayList<Plane>()
    val zones = ArrayList<Zone>()
    var nextId = 1
    var time = 0f
    var state = 0 // ۰ در جریان، ۱ پیروزی، ۲ شکست
    var endT = 0f
    var waveIdx = 0
    var waveT = 0f
    var startCount = 0
    var lostCount = 0
    var killCount = 0
    var shakeReq = 0f
    var spawnedWaves = 0

    var sfx: (String) -> Unit = {}
    var say: (String, Float, Float, Int) -> Unit = { _, _, _, _ -> }

    private val enemyLvl = 1 + (m.diff * 0.8f).toInt()

    private val tiers = arrayOf(
        intArrayOf(0, 0, 0, 1, 5, 6, 58),
        intArrayOf(0, 1, 2, 5, 7, 10, 19, 12, 50, 56, 59),
        intArrayOf(3, 4, 8, 9, 22, 31, 30, 11, 51, 55, 61, 62),
        intArrayOf(33, 3, 4, 9, 22, 32, 37, 20, 27, 63, 64, 53),
        intArrayOf(34, 36, 38, 39, 42, 25, 21, 29, 65, 70, 54),
        intArrayOf(35, 41, 43, 44, 34, 36, 39, 66, 67, 68, 69, 71)
    )

    init {
        // نیروهای ما
        val n = squadIds.size
        for (i in 0 until n) {
            val col = i % 5
            val row = i / 5
            val px = map.startX - 2f + col * 1.15f
            val py = map.startY + row * 1.1f
            val role = Roles.byId(squadIds[i])
            val c = nearestPass(px, py, role.kind == 1)
            val mob = Mob(nextId++, role, 0, c[0] + 0.5f, c[1] + 0.5f, levelOf(role.id))
            mob.abT = 3f
            mob.selected = true
            mobs.add(mob)
        }
        startCount = n
        for (id in cardIds) cards.add(Card(Roles.byId(id), levelOf(id)))
        for (z in map.zones) zones.add(Zone(z[0], z[1], 2.6f))
        setupEnemies()
    }

    // ------------------------------------------------------------ زمین
    fun passType(tp: Int, veh: Boolean): Boolean =
        if (veh) tp == 0 || tp == 1 || tp == 8 else tp == 0 || tp == 1 || tp == 3 || tp == 5 || tp == 6 || tp == 8

    fun passCell(cx: Int, cy: Int, veh: Boolean): Boolean = passType(map.at(cx, cy), veh)

    fun nearestPass(x: Float, y: Float, veh: Boolean): IntArray {
        val cx = x.toInt()
        val cy = y.toInt()
        if (passCell(cx, cy, veh)) return intArrayOf(cx, cy)
        for (r in 1..8) {
            for (dy in -r..r) for (dx in -r..r) {
                if (max(abs(dx), abs(dy)) != r) continue
                if (passCell(cx + dx, cy + dy, veh)) return intArrayOf(cx + dx, cy + dy)
            }
        }
        return intArrayOf(cx.coerceIn(0, cols - 1), cy.coerceIn(0, rows - 1))
    }

    private fun costOf(tp: Int, veh: Boolean): Float = when (tp) {
        3 -> 1.6f
        5 -> 1.4f
        6 -> 1.5f
        1, 8 -> if (veh) 0.8f else 0.9f
        else -> 1f
    }

    private class Node(val i: Int, val f: Float) : Comparable<Node> {
        override fun compareTo(other: Node): Int = f.compareTo(other.f)
    }

    fun findPath(sx: Int, sy: Int, gx0: Int, gy0: Int, veh: Boolean): IntArray {
        val g0 = nearestPass(gx0 + 0.5f, gy0 + 0.5f, veh)
        val gx = g0[0]
        val gy = g0[1]
        val start = sy * cols + sx
        val goal = gy * cols + gx
        if (start == goal) return IntArray(0)
        val n = cols * rows
        val gs = FloatArray(n) { 1e9f }
        val came = IntArray(n) { -1 }
        val closed = BooleanArray(n)
        val open = PriorityQueue<Node>()
        gs[start] = 0f
        open.add(Node(start, 0f))
        var found = false
        var guard = 0
        while (open.isNotEmpty() && guard < 6000) {
            guard++
            val cur = open.poll() ?: break
            if (closed[cur.i]) continue
            closed[cur.i] = true
            if (cur.i == goal) {
                found = true
                break
            }
            val cx = cur.i % cols
            val cy = cur.i / cols
            for (dy in -1..1) for (dx in -1..1) {
                if (dx == 0 && dy == 0) continue
                val nx = cx + dx
                val ny = cy + dy
                if (nx < 0 || ny < 0 || nx >= cols || ny >= rows) continue
                if (!passCell(nx, ny, veh)) continue
                if (dx != 0 && dy != 0 && (!passCell(cx + dx, cy, veh) || !passCell(cx, cy + dy, veh))) continue
                val ni = ny * cols + nx
                if (closed[ni]) continue
                val step = (if (dx != 0 && dy != 0) 1.414f else 1f) * costOf(map.at(nx, ny), veh)
                val ng = gs[cur.i] + step
                if (ng < gs[ni]) {
                    gs[ni] = ng
                    came[ni] = cur.i
                    val h = max(abs(nx - gx), abs(ny - gy)).toFloat()
                    open.add(Node(ni, ng + h))
                }
            }
        }
        if (!found) return IntArray(0)
        val list = ArrayList<Int>()
        var c = goal
        while (c != start && c >= 0) {
            list.add(c)
            c = came[c]
        }
        list.reverse()
        return list.toIntArray()
    }

    fun goTo(m: Mob, tx: Float, ty: Float) {
        val veh = m.role.kind == 1
        val sx = m.x.toInt().coerceIn(0, cols - 1)
        val sy = m.y.toInt().coerceIn(0, rows - 1)
        val p = findPath(sx, sy, tx.toInt().coerceIn(0, cols - 1), ty.toInt().coerceIn(0, rows - 1), veh)
        m.path = p
        m.pi = 0
        m.hasGoal = p.isNotEmpty()
    }

    // ------------------------------------------------------------ دید و تیراندازی
    fun dist(a: Mob, b: Mob): Float = hyp(a.x - b.x, a.y - b.y)
    fun hyp(dx: Float, dy: Float): Float = sqrt(dx * dx + dy * dy)

    fun los(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val d = hyp(x2 - x1, y2 - y1)
        val steps = ceil(d / 0.35f).toInt()
        for (i in 1 until steps) {
            val k = i / steps.toFloat()
            val px = x1 + (x2 - x1) * k
            val py = y1 + (y2 - y1) * k
            if (map.at(px.toInt(), py.toInt()) == 4) return false
            for (s in smokes) if (hyp(px - s.x, py - s.y) < s.r * 0.85f) return false
        }
        return true
    }

    fun visible(from: Mob, t: Mob, d: Float): Boolean {
        if (t.dead) return false
        if (t.camo > 0f && d > 2.2f) return false
        if (map.at(t.x.toInt(), t.y.toInt()) == 3 && d > 4.5f && t.flash <= 0f) return false
        return true
    }

    private fun spotted(t: Mob, team: Int): Boolean {
        for (o in mobs) {
            if (o.team != team || o.dead || o.role.isIndirect) continue
            val d = hyp(o.x - t.x, o.y - t.y)
            if (d < 9f && visible(o, t, d) && los(o.x, o.y, t.x, t.y)) return true
        }
        return false
    }

    private fun acquire(m: Mob): Mob? {
        val rg = m.role.range
        if (rg <= 0f || m.role.dmg <= 0f) return null
        var best: Mob? = null
        var bs = 1e9f
        for (o in mobs) {
            if (o.team == m.team || o.dead) continue
            val d = hyp(o.x - m.x, o.y - m.y)
            if (d > rg) continue
            if (!visible(m, o, d)) continue
            if (m.role.isIndirect) {
                if (!spotted(o, m.team)) continue
            } else if (!los(m.x, m.y, o.x, o.y)) continue
            var sc = d
            if (m.role.at >= 1.5f && o.role.kind == 1) sc -= 4f
            if (m.role.at <= 0.4f && o.role.kind == 1) sc += 3f
            if (sc < bs) {
                bs = sc
                best = o
            }
        }
        return best
    }

    private fun turnTo(cur: Float, want: Float, step: Float): Float {
        var d = want - cur
        while (d > PI_F) d -= 2f * PI_F
        while (d < -PI_F) d += 2f * PI_F
        return if (abs(d) <= step) want else cur + (if (d > 0f) step else -step)
    }

    private fun angDiff(a: Float, b: Float): Float {
        var d = b - a
        while (d > PI_F) d -= 2f * PI_F
        while (d < -PI_F) d += 2f * PI_F
        return abs(d)
    }

    fun inCover(m: Mob): Float {
        if (m.role.kind != 0) return 0f
        return when (map.at(m.x.toInt(), m.y.toInt())) {
            3 -> 0.25f
            5, 6 -> 0.35f
            else -> 0f
        }
    }

    fun damage(t: Mob, raw: Float, at: Float, src: Mob?) {
        if (t.dead) return
        var d = raw
        if (t.role.kind == 1) d *= at
        d *= (1f - t.role.armor)
        if (t.fort > 0f) d *= 0.5f
        d *= (1f - inCover(t))
        t.hp -= d
        t.hurt = 0.25f
        if (!t.alert && t.team == 1) t.alert = true
        if (t.hp <= 0f) die(t, src)
    }

    private fun die(t: Mob, src: Mob?) {
        t.dead = true
        t.deadT = 0f
        t.hp = 0f
        t.selected = false
        if (src != null) src.kills++
        if (t.team == 1) killCount++ else lostCount++
        if (t.role.kind == 1) {
            blasts.add(Blast(t.x, t.y, 1.6f, 0.7f, 0.7f, 0))
            fires.add(Fire(t.x, t.y, 0.9f, 8f, 0f))
            sfx("boom")
            shakeReq = max(shakeReq, 0.5f)
        } else {
            blasts.add(Blast(t.x, t.y, 0.4f, 0.35f, 0.35f, 2))
            sfx("die")
        }
    }

    fun explode(x: Float, y: Float, r: Float, dmg: Float, at: Float, src: Mob?, big: Boolean) {
        blasts.add(Blast(x, y, r, 0.55f, 0.55f, 0))
        if (r >= 1f) craters.add(Crater(x, y, r * 0.55f))
        sfx(if (r >= 1.3f) "boom" else "explode")
        shakeReq = max(shakeReq, min(0.8f, r * 0.3f))
        for (o in mobs) {
            if (o.dead) continue
            val d = hyp(o.x - x, o.y - y)
            if (d > r + o.r * 0.6f) continue
            val f = (1f - d / (r + 0.001f) * 0.55f).coerceIn(0.35f, 1f)
            damage(o, dmg * f, at, src)
            if (o.role.kind == 0 && !o.dead) o.supp = max(o.supp, 1.2f)
        }
        if (big) for (mn in ArrayList(mines)) if (hyp(mn.x - x, mn.y - y) < r) mines.remove(mn)
    }

    private fun fire(m: Mob, t: Mob, d: Float) {
        val role = m.role
        m.cd = 1f / (role.rate * (if (m.rally > 0f) 1.2f else 1f))
        m.flash = 0.1f
        m.camo = 0f
        val dm = role.dmg * m.mult * (if (m.rally > 0f) 1.25f else 1f)
        val ang = atan2(t.y - m.y, t.x - m.x)
        val mx = m.x + cos(ang) * (m.r + 0.25f)
        val my = m.y + sin(ang) * (m.r + 0.25f)
        val heavy = role.kind == 1 || role.splash > 0f
        if (role.splash > 0f) {
            val kind = when {
                role.wpn == 5 || role.wpn == 13 || role.wpn == 32 || role.wpn == 42 -> 1
                role.isIndirect -> 3
                role.wpn == 10 -> 2
                else -> 0
            }
            val scatter = 0.2f + d * 0.04f * (if (role.isIndirect) 2.2f else 1f)
            val tx = t.x + (rnd.nextFloat() - 0.5f) * 2f * scatter
            val ty = t.y + (rnd.nextFloat() - 0.5f) * 2f * scatter
            val speed = when (kind) {
                0 -> 22f
                1 -> 13f
                2 -> 8f
                else -> 9f
            }
            projs.add(Proj(mx, my, mx, my, tx, ty, 0f, max(0.12f, d / speed), dm, role.splash, role.at, kind))
            sfx(if (kind == 1) "rocket" else "cannon")
        } else {
            var acc = 0.80f - d / role.range * 0.30f
            if (m.moving) acc *= 0.7f
            if (m.supp > 0f) acc *= 0.55f
            if (m.recon > 0f) acc += 0.15f
            acc *= (1f - inCover(t) * 1.2f)
            if (m.team == 1) acc *= 0.85f + m.lvl * 0.012f
            if (role.wpn == 3) acc += 0.15f
            if (rnd.nextFloat() < acc) {
                tracers.add(Tracer(mx, my, t.x, t.y, 0.09f, heavy))
                damage(t, dm, role.at, m)
            } else {
                val off = (rnd.nextFloat() - 0.5f) * 1.2f
                tracers.add(Tracer(mx, my, t.x - sin(ang) * off, t.y + cos(ang) * off, 0.09f, heavy))
                if (t.role.kind == 0 && (role.wpn == 2 || role.wpn == 1)) t.supp = max(t.supp, 0.6f)
            }
            sfx(if (role.wpn == 2 || role.wpn == 1 || role.wpn == 27 || role.wpn == 20 || role.wpn == 21 || role.wpn == 22 || role.wpn == 35 || role.wpn == 40) "mg" else if (role.kind == 1) "cannon" else "shot")
        }
        if (role.wpn == 6 || role.wpn == 29) {
            blasts.add(Blast(mx + cos(ang) * 0.6f, my + sin(ang) * 0.6f, 0.5f, 0.25f, 0.25f, 3))
        }
    }

    // ------------------------------------------------------------ آماده‌سازی دشمن

    private fun pickEnemy(diff: Int): Int {
        val tier = (if (rnd.nextInt(3) == 0) diff - 1 else diff).coerceIn(0, tiers.size - 1)
        val pool = tiers[tier]
        var id = pool[rnd.nextInt(pool.size)]
        // خودروها و تانک‌ها در سطح پایین کمتر باشند
        if (diff <= 1 && Roles.byId(id).kind == 1) id = 0
        return id
    }

    private fun spawnEnemy(roleId: Int, x: Float, y: Float, alert: Boolean): Mob {
        val role = Roles.byId(roleId)
        val c = nearestPass(x, y, role.kind == 1)
        val mob = Mob(nextId++, role, 1, c[0] + 0.5f, c[1] + 0.5f, enemyLvl)
        mob.alert = alert
        mob.abT = 3f + rnd.nextFloat() * 6f
        mobs.add(mob)
        return mob
    }

    private fun setupEnemies() {
        // سنگرهای ثابت
        for ((i, b) in map.bunkers.withIndex()) {
            val role = if (i % 2 == 0) Roles.bunker else Roles.atNest
            val mob = Mob(nextId++, role, 1, b[0], b[1], enemyLvl)
            mob.alert = true
            mob.face = PI_F / 2f
            mob.turret = mob.face
            mobs.add(mob)
        }
        if (m.type == 2) return // مقاومت: فقط موج‌ها
        var left = m.enemies
        val spots = ArrayList<FloatArray>()
        if (zones.isNotEmpty()) {
            for (z in zones) spots.add(floatArrayOf(z.cx, z.cy - 1.5f))
        }
        for (i in 0 until 5) {
            spots.add(floatArrayOf(2f + rnd.nextFloat() * (cols - 4f), 2f + rnd.nextFloat() * rows * 0.45f))
        }
        var si = 0
        while (left > 0) {
            val sp = spots[si % spots.size]
            val grp = min(left, 2 + rnd.nextInt(3))
            for (k in 0 until grp) {
                spawnEnemy(pickEnemy(m.diff), sp[0] + (rnd.nextFloat() - 0.5f) * 2.5f, sp[1] + (rnd.nextFloat() - 0.5f) * 2f, false)
            }
            left -= grp
            si++
        }
    }

    private fun spawnWave() {
        val count = 2 + m.diff / 2 + waveIdx / 2 + (if (m.type == 2) 1 else 0)
        // از لبه‌ی بالای نقشه، نزدیک جاده
        val roadX = map.startX
        for (i in 0 until count) {
            val x = (roadX + (rnd.nextFloat() - 0.5f) * 8f).coerceIn(1.5f, cols - 1.5f)
            spawnEnemy(pickEnemy(m.diff), x, 0.8f + rnd.nextFloat() * 1.5f, true)
        }
        waveIdx++
        spawnedWaves++
        sfx("alarm")
        say("هجوم جدید دشمن!", cols / 2f, 3f, 1)
    }

    // ------------------------------------------------------------ دستورها
    fun players(): List<Mob> = mobs.filter { it.team == 0 && !it.dead }
    fun enemiesAlive(): Int = mobs.count { it.team == 1 && !it.dead }

    fun orderMove(sel: List<Mob>, tx: Float, ty: Float) {
        var i = 0
        for (m in sel) {
            if (m.dead || m.role.speed <= 0f) continue
            val ring = 1 + i / 6
            val a = i * 1.05f
            val ox = cos(a) * 0.85f * (ring - 1) * (if (i == 0) 0f else 1f)
            val oy = sin(a) * 0.85f * (ring - 1) * (if (i == 0) 0f else 1f)
            m.forced = null
            goTo(m, tx + ox, ty + oy)
            i++
        }
    }

    fun orderAttack(sel: List<Mob>, enemy: Mob) {
        for (m in sel) {
            if (m.dead) continue
            m.forced = enemy
            m.repathT = 0f
        }
    }

    fun castMob(m: Mob, tx: Float, ty: Float): Boolean {
        val role = m.role
        if (m.dead || role.ab == Ab.NONE || m.abT > 0f) return false
        var x = tx
        var y = ty
        val rg = Roles.abRange(role)
        if (Ab.needsTarget(role.ab) && rg > 0f && rg < 50f) {
            val d = hyp(tx - m.x, ty - m.y)
            if (d > rg && role.ab != Ab.DASH) {
                val k = rg / d
                x = m.x + (tx - m.x) * k
                y = m.y + (ty - m.y) * k
            }
        }
        val ok = doAbility(role.ab, role, m.mult, m.team, m, m.x, m.y, x, y)
        if (ok) {
            m.abT = role.cd
            m.camo = if (role.ab == Ab.CAMO) role.pow else m.camo
        }
        return ok
    }

    fun castCard(c: Card, tx: Float, ty: Float): Boolean {
        if (c.cd > 0f) return false
        val ok = doAbility(c.role.ab, c.role, Roles.mult(c.lvl), 0, null, tx, map.rows.toFloat(), tx, ty)
        if (ok) c.cd = c.role.cd
        return ok
    }

    private fun friendsNear(team: Int, x: Float, y: Float, r: Float, kind: Int): List<Mob> =
        mobs.filter { it.team == team && !it.dead && it.role.kind == kind && hyp(it.x - x, it.y - y) <= r }

    private fun doAbility(ab: Int, role: Role, mult: Float, team: Int, src: Mob?, sx: Float, sy: Float, tx: Float, ty: Float): Boolean {
        val pw = role.pow * mult
        when (ab) {
            Ab.HEAL -> {
                val cx = if (src != null) src.x else tx
                val cy = if (src != null) src.y else ty
                var n = 0
                for (o in friendsNear(team, cx, cy, role.rad, 0)) {
                    o.hp = min(o.maxHp, o.hp + pw)
                    say("+", o.x, o.y - 0.4f, 3)
                    n++
                }
                blasts.add(Blast(cx, cy, role.rad, 0.7f, 0.7f, 4))
                sfx("heal")
                return true
            }
            Ab.REPAIR -> {
                val cx = if (src != null) src.x else tx
                val cy = if (src != null) src.y else ty
                for (o in friendsNear(team, cx, cy, role.rad, 1)) {
                    o.hp = min(o.maxHp, o.hp + pw)
                    say("+", o.x, o.y - 0.5f, 3)
                }
                blasts.add(Blast(cx, cy, role.rad, 0.7f, 0.7f, 4))
                sfx("heal")
                return true
            }
            Ab.GRENADE -> {
                val d = hyp(tx - sx, ty - sy)
                projs.add(Proj(sx, sy, sx, sy, tx, ty, 0f, max(0.25f, d / 8f), pw, role.rad, 0.9f, 2))
                sfx("order")
                return true
            }
            Ab.ROCKET -> {
                val fx = if (src != null) sx else tx
                val fy = if (src != null) sy else ty - 14f
                val d = hyp(tx - fx, ty - fy)
                val at = if (role.kind == 2) 2.5f else max(role.at, 1.2f)
                projs.add(Proj(fx, fy, fx, fy, tx, ty, 0f, max(0.3f, d / 14f), pw, role.rad, at, 1))
                sfx("rocket")
                return true
            }
            Ab.SMOKE -> {
                smokes.add(Smoke(tx, ty, role.rad, 10f, 10f))
                sfx("order")
                return true
            }
            Ab.SNIPE -> {
                var best: Mob? = null
                var bd = 1.8f
                for (o in mobs) {
                    if (o.team == team || o.dead) continue
                    val d = hyp(o.x - tx, o.y - ty)
                    if (d < bd) {
                        bd = d
                        best = o
                    }
                }
                val b = best ?: return false
                tracers.add(Tracer(sx, sy, b.x, b.y, 0.18f, true))
                damage(b, pw, 0.8f, src)
                sfx("cannon")
                say("شلیک مرگبار!", b.x, b.y - 0.6f, 2)
                return true
            }
            Ab.MINE -> {
                val d = hyp(tx - sx, ty - sy)
                val k = if (d > 0.01f) min(1f, 1.2f / d) else 0f
                val px = sx + (tx - sx) * k
                val py = sy + (ty - sy) * k
                if (mines.count { it.team == team } >= 8) return false
                mines.add(Mine(px, py, team, pw, role.rad))
                sfx("order")
                return true
            }
            Ab.AIRSTRIKE -> {
                planes.add(Plane(tx - 6f, ty + 14f, 0f, -20f, 1.5f, 0))
                planes.add(Plane(tx + 2f, ty + 16f, 0f, -20f, 1.5f, 0))
                for (i in 0 until 6) delays.add(Delay(1.6f + 0.17f * i, tx + (i % 2) * 0.3f, ty - 3f + 1.1f * i, pw, role.rad, 1.2f, 0))
                sfx("whistle")
                say("بمباران در راه است!", tx, ty - 1f, 4)
                return true
            }
            Ab.STRAFE -> {
                planes.add(Plane(tx - 12f, ty, 22f, 0f, 1.2f, 1))
                for (i in 0 until 10) delays.add(Delay(1.2f + 0.1f * i, tx - 5f + i * 1.1f, ty, pw, role.rad, 0.6f, 0))
                sfx("whistle")
                return true
            }
            Ab.ARTILLERY -> {
                val n = if (src == null) 6 else 4
                for (i in 0 until n) {
                    val a = rnd.nextFloat() * 6.28f
                    val rr = rnd.nextFloat() * 1.7f
                    delays.add(Delay(1.2f + 0.45f * i, tx + cos(a) * rr, ty + sin(a) * rr, pw, role.rad, 1.0f, 0))
                }
                blasts.add(Blast(tx, ty, 1.7f, 1.2f, 1.2f, 5))
                sfx("whistle")
                return true
            }
            Ab.NAVAL -> {
                for (i in 0 until 7) {
                    val a = rnd.nextFloat() * 6.28f
                    val rr = rnd.nextFloat() * 3.0f
                    delays.add(Delay(2.0f + 0.5f * i, tx + cos(a) * rr, ty + sin(a) * rr, pw, role.rad, 1.5f, 0))
                }
                blasts.add(Blast(tx, ty, 3.2f, 2f, 2f, 5))
                sfx("whistle")
                say("آتش ناوگان!", tx, ty - 1f, 4)
                return true
            }
            Ab.FLAME -> {
                val ang = atan2(ty - sy, tx - sx)
                var hitAny = false
                for (o in mobs) {
                    if (o.team == team || o.dead) continue
                    val d = hyp(o.x - sx, o.y - sy)
                    if (d > role.rad) continue
                    if (angDiff(ang, atan2(o.y - sy, o.x - sx)) > 0.65f) continue
                    damage(o, pw, 0.7f, src)
                    o.burn = 4f
                    hitAny = true
                }
                for (i in 1..5) blasts.add(Blast(sx + cos(ang) * i * 0.7f, sy + sin(ang) * i * 0.7f, 0.6f + i * 0.08f, 0.45f, 0.45f, 3))
                sfx("flame")
                return true
            }
            Ab.RALLY -> {
                val cx = if (src != null) src.x else tx
                val cy = if (src != null) src.y else ty
                for (o in mobs) if (o.team == team && !o.dead && hyp(o.x - cx, o.y - cy) <= role.rad) o.rally = role.pow
                blasts.add(Blast(cx, cy, role.rad, 0.8f, 0.8f, 4))
                sfx("order")
                say("به پیش!", cx, cy - 0.7f, 4)
                return true
            }
            Ab.CAMO -> {
                if (src != null) src.camo = role.pow
                sfx("order")
                return true
            }
            Ab.DASH -> {
                if (src == null) return false
                src.dash = 2.6f
                src.forced = null
                goTo(src, tx, ty)
                sfx("order")
                return true
            }
            Ab.FORTIFY -> {
                if (src != null) src.fort = role.pow
                blasts.add(Blast(sx, sy, 1.0f, 0.5f, 0.5f, 4))
                sfx("order")
                return true
            }
            Ab.SUPPRESS -> {
                for (o in mobs) {
                    if (o.team == team || o.dead) continue
                    if (hyp(o.x - tx, o.y - ty) <= role.rad) {
                        o.supp = 5f
                        tracers.add(Tracer(sx, sy, o.x, o.y, 0.12f, false))
                    }
                }
                blasts.add(Blast(tx, ty, role.rad, 0.6f, 0.6f, 5))
                sfx("mg")
                return true
            }
            Ab.RECON -> {
                for (o in mobs) if (o.team == team && !o.dead) o.recon = max(o.recon, role.pow)
                sfx("order")
                say("شناسایی انجام شد", map.startX, map.startY - 2f, 4)
                return true
            }
            Ab.SUPPLY -> {
                for (o in mobs) {
                    if (o.team != team || o.dead) continue
                    if (o.role.kind == 0) o.hp = min(o.maxHp, o.hp + o.maxHp * role.pow)
                    o.abT *= 0.5f
                }
                for (c in cards) c.cd *= 0.6f
                sfx("heal")
                say("تدارکات رسید", map.startX, map.startY - 2f, 3)
                return true
            }
            Ab.PARADROP -> {
                planes.add(Plane(tx - 10f, ty - 3f, 16f, 0f, 1.5f, 2))
                for (i in 0 until pw.toInt().coerceAtLeast(1)) {
                    val u = Mob(nextId++, Roles.byId(0), 0, tx + (i - 1) * 0.9f, ty + 0.5f, 1 + (mult * 3f).toInt().coerceAtMost(9))
                    u.abT = 3f
                    mobs.add(u)
                    startCount++
                    blasts.add(Blast(u.x, u.y, 0.5f, 0.4f, 0.4f, 6))
                }
                sfx("order")
                return true
            }
            Ab.NAPALM -> {
                planes.add(Plane(tx - 12f, ty, 22f, 0f, 1.2f, 1))
                fires.add(Fire(tx, ty, role.rad, 12f, pw))
                blasts.add(Blast(tx, ty, role.rad, 0.8f, 0.8f, 3))
                sfx("flame")
                return true
            }
        }
        return false
    }

    // ------------------------------------------------------------ به‌روزرسانی
    fun update(dt0: Float) {
        val dt = min(dt0, 0.05f)
        if (state != 0) {
            endT += dt
        } else {
            time += dt
        }
        for (c in cards) if (c.cd > 0f) c.cd = max(0f, c.cd - dt)

        if (state == 0) {
            // موج‌های دشمن
            if (m.type == 2) {
                waveT -= dt
                if (waveT <= 0f) {
                    waveT = max(13f, 24f - m.diff * 1.2f)
                    spawnWave()
                }
            } else if (m.waves > 0 && spawnedWaves < m.waves) {
                waveT += dt
                if (waveT > 50f) {
                    waveT = 0f
                    spawnWave()
                }
            }
        }

        for (mob in mobs) updateMob(mob, dt)
        if (state == 0) separate()
        updateEffects(dt)
        if (state == 0) checkObjective(dt)
        // پاک‌سازی
        val it = mobs.iterator()
        while (it.hasNext()) {
            val mb = it.next()
            if (mb.dead && mb.deadT > 6f) it.remove()
        }
    }

    private fun updateMob(m: Mob, dt: Float) {
        if (m.dead) {
            m.deadT += dt
            return
        }
        m.cd -= dt
        m.abT -= dt
        m.camo -= dt
        m.fort -= dt
        m.rally -= dt
        m.supp -= dt
        m.dash -= dt
        m.recon -= dt
        m.flash -= dt
        m.hurt -= dt
        if (m.burn > 0f) {
            m.burn -= dt
            damage(m, 7f * dt * 4f * 0.25f * 4f, 1f, null)
            if (m.dead) return
        }
        if (state != 0) {
            m.moving = false
            return
        }
        m.scanT -= dt
        val role = m.role

        // انتخاب هدف
        if (m.scanT <= 0f) {
            m.scanT = 0.25f + rnd.nextFloat() * 0.1f
            val f = m.forced
            if (f != null && !f.dead) {
                val d = dist(m, f)
                if (d <= role.range && visible(m, f, d) && (role.isIndirect || los(m.x, m.y, f.x, f.y))) m.target = f else m.target = acquire(m)
            } else {
                m.forced = null
                m.target = acquire(m)
            }
        }
        val tg = m.target
        if (tg != null && tg.dead) m.target = null

        // فرمان حمله‌ی بازیکن
        val f = m.forced
        if (m.team == 0 && f != null && !f.dead) {
            val d = dist(m, f)
            if (d > role.range * 0.92f || (!role.isIndirect && !los(m.x, m.y, f.x, f.y))) {
                m.repathT -= dt
                if (m.repathT <= 0f) {
                    m.repathT = 0.8f
                    goTo(m, f.x, f.y)
                }
            } else if (m.hasGoal) {
                m.hasGoal = false
            }
        } else if (m.team == 0 && f != null && f.dead) {
            m.forced = null
        }

        if (m.team == 1) aiThink(m, dt)

        // حرکت
        move(m, dt)

        // هدف‌گیری و شلیک
        val t = m.target
        if (t != null && !t.dead) {
            val want = atan2(t.y - m.y, t.x - m.x)
            if (role.kind == 1 && role.wpn != 28 && role.wpn != 38 && role.wpn != 41) {
                m.turret = turnTo(m.turret, want, 3.2f * dt)
            } else if (role.kind == 1) {
                m.turret = turnTo(m.turret, want, 2.2f * dt)
                if (!m.moving) m.face = m.turret
            } else {
                m.face = turnTo(m.face, want, 12f * dt)
                m.turret = m.face
            }
            val d = dist(m, t)
            val aimed = angDiff(if (role.kind == 1) m.turret else m.face, want) < 0.3f
            if (m.cd <= 0f && d <= role.range && aimed && role.dmg > 0f) fire(m, t, d)
        } else if (role.kind == 1) {
            m.turret = turnTo(m.turret, m.face, 2.5f * dt)
        }
        // مین
        if (m.team == 1 || m.team == 0) {
            for (mn in ArrayList(mines)) {
                if (mn.team != m.team && hyp(mn.x - m.x, mn.y - m.y) < 0.9f && !m.dead) {
                    mines.remove(mn)
                    explode(mn.x, mn.y, mn.rad, mn.dmg, 1.2f, null, false)
                }
            }
        }
        // مین‌روب
        if (role.wpn == 43) for (mn in ArrayList(mines)) if (mn.team != m.team && hyp(mn.x - m.x, mn.y - m.y) < 2.2f) mines.remove(mn)
    }

    private fun move(m: Mob, dt: Float) {
        m.moving = false
        val role = m.role
        if (role.speed <= 0f || !m.hasGoal || m.pi >= m.path.size) {
            m.hasGoal = false
            return
        }
        val c = m.path[m.pi]
        val tx = (c % cols) + 0.5f
        val ty = (c / cols) + 0.5f
        val dx = tx - m.x
        val dy = ty - m.y
        val d = hyp(dx, dy)
        val tp = map.at(m.x.toInt(), m.y.toInt())
        val veh = role.kind == 1
        var sp = role.speed / costOf(tp, veh)
        if (m.dash > 0f) sp *= 2.4f
        if (m.supp > 0f) sp *= 0.7f
        if (m.fort > 0f) sp *= 0.5f
        if (m.rally > 0f) sp *= 1.2f
        val want = atan2(dy, dx)
        if (veh) {
            m.face = turnTo(m.face, want, 2.6f * dt)
            if (angDiff(m.face, want) > 0.9f) return
        } else if (m.target == null) {
            m.face = turnTo(m.face, want, 10f * dt)
        }
        val step = sp * dt
        if (d <= step + 0.04f) {
            m.x = tx
            m.y = ty
            m.pi++
            if (m.pi >= m.path.size) m.hasGoal = false
        } else {
            m.x += dx / d * step
            m.y += dy / d * step
        }
        m.moving = true
        m.walk += dt * sp * 3.4f
        m.dustT -= dt
    }

    private fun separate() {
        val n = mobs.size
        for (i in 0 until n) {
            val a = mobs[i]
            if (a.dead) continue
            for (j in i + 1 until n) {
                val b = mobs[j]
                if (b.dead) continue
                val dx = b.x - a.x
                val dy = b.y - a.y
                val rr = (a.r + b.r) * 0.85f
                if (abs(dx) > rr || abs(dy) > rr) continue
                val d = hyp(dx, dy)
                if (d >= rr || d < 0.0001f) continue
                val push = (rr - d) * 0.5f
                val nx = dx / d
                val ny = dy / d
                val aStatic = a.role.speed <= 0f
                val bStatic = b.role.speed <= 0f
                if (!aStatic) {
                    a.x -= nx * push * (if (bStatic) 2f else 1f)
                    a.y -= ny * push * (if (bStatic) 2f else 1f)
                }
                if (!bStatic) {
                    b.x += nx * push * (if (aStatic) 2f else 1f)
                    b.y += ny * push * (if (aStatic) 2f else 1f)
                }
            }
            val vv = a.role.kind == 1
            if (!passCell(a.x.toInt(), a.y.toInt(), vv)) {
                val c = nearestPass(a.x, a.y, vv)
                a.x = c[0] + 0.5f
                a.y = c[1] + 0.5f
            }
            a.x = a.x.coerceIn(0.3f, cols - 0.3f)
            a.y = a.y.coerceIn(0.3f, rows - 0.3f)
        }
    }

    private fun updateEffects(dt: Float) {
        var i = tracers.size - 1
        while (i >= 0) {
            tracers[i].life -= dt
            if (tracers[i].life <= 0f) tracers.removeAt(i)
            i--
        }
        i = projs.size - 1
        while (i >= 0) {
            val p = projs[i]
            p.t += dt
            val k = (p.t / p.dur).coerceIn(0f, 1f)
            p.x = p.sx + (p.tx - p.sx) * k
            p.y = p.sy + (p.ty - p.sy) * k
            if (p.t >= p.dur) {
                projs.removeAt(i)
                explode(p.tx, p.ty, max(0.4f, p.splash), p.dmg, p.at, null, p.kind >= 1)
            }
            i--
        }
        i = delays.size - 1
        while (i >= 0) {
            val d = delays[i]
            d.t -= dt
            if (d.t <= 0f) {
                delays.removeAt(i)
                explode(d.x, d.y, d.rad, d.dmg, d.at, null, true)
            }
            i--
        }
        i = blasts.size - 1
        while (i >= 0) {
            blasts[i].life -= dt
            if (blasts[i].life <= 0f) blasts.removeAt(i)
            i--
        }
        i = smokes.size - 1
        while (i >= 0) {
            smokes[i].life -= dt
            if (smokes[i].life <= 0f) smokes.removeAt(i)
            i--
        }
        i = fires.size - 1
        while (i >= 0) {
            val f = fires[i]
            f.life -= dt
            if (f.dps > 0f) {
                for (o in mobs) {
                    if (o.dead) continue
                    if (hyp(o.x - f.x, o.y - f.y) <= f.r) damage(o, f.dps * dt, 0.8f, null)
                }
            }
            if (f.life <= 0f) fires.removeAt(i)
            i--
        }
        i = planes.size - 1
        while (i >= 0) {
            val p = planes[i]
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.life -= dt
            if (p.life <= 0f) planes.removeAt(i)
            i--
        }
    }

    // ------------------------------------------------------------ هوش دشمن
    private fun nearestPlayer(m: Mob): Mob? {
        var best: Mob? = null
        var bd = 1e9f
        for (o in mobs) {
            if (o.team != 0 || o.dead) continue
            val d = hyp(o.x - m.x, o.y - m.y)
            if (d < bd) {
                bd = d
                best = o
            }
        }
        return best
    }

    private fun aiThink(m: Mob, dt: Float) {
        val role = m.role
        m.thinkT -= dt
        if (m.thinkT > 0f) return
        m.thinkT = 0.35f
        val near = nearestPlayer(m)
        if (!m.alert) {
            if (near != null && (m.hurt > 0f || hyp(near.x - m.x, near.y - m.y) < 9.5f)) {
                m.alert = true
                for (o in mobs) if (o.team == 1 && !o.alert && !o.dead && hyp(o.x - m.x, o.y - m.y) < 6f) o.alert = true
            }
            return
        }
        aiAbility(m)
        if (role.speed <= 0f) return
        val tg = m.target
        if (tg != null && dist(m, tg) <= role.range * 0.85f) {
            m.flankT -= 0.35f
            if (m.flankT <= 0f) {
                m.flankT = 4f + rnd.nextFloat() * 5f
                if (role.kind == 0 && rnd.nextFloat() < 0.4f) {
                    goTo(m, m.x + (rnd.nextFloat() - 0.5f) * 5f, m.y + (rnd.nextFloat() - 0.2f) * 3f)
                } else {
                    m.hasGoal = false
                }
            } else if (!m.hasGoal) {
                // همان‌جا بایست و شلیک کن
            }
        } else if (near != null) {
            m.repathT -= 0.35f
            if (m.repathT <= 0f) {
                m.repathT = 1.0f + rnd.nextFloat() * 0.6f
                // برای تصرف: به سمت نقطه‌ی تصرف بروند
                var gx = near.x
                var gy = near.y
                if (zones.isNotEmpty() && rnd.nextInt(3) == 0) {
                    val z = zones[rnd.nextInt(zones.size)]
                    gx = z.cx
                    gy = z.cy
                }
                goTo(m, gx, gy)
            }
        }
    }

    private fun aiAbility(m: Mob) {
        val role = m.role
        if (role.ab == Ab.NONE || m.abT > 0f) return
        val t = m.target
        val d = if (t != null) dist(m, t) else 999f
        when (role.ab) {
            Ab.HEAL -> {
                for (o in friendsNear(1, m.x, m.y, role.rad, 0)) if (o.hp < o.maxHp * 0.65f) {
                    castMob(m, m.x, m.y)
                    return
                }
            }
            Ab.REPAIR -> {
                for (o in friendsNear(1, m.x, m.y, role.rad, 1)) if (o.hp < o.maxHp * 0.65f) {
                    castMob(m, m.x, m.y)
                    return
                }
            }
            Ab.GRENADE, Ab.ROCKET, Ab.SNIPE, Ab.SUPPRESS, Ab.ARTILLERY -> {
                if (t != null && d >= 2f && d <= Roles.abRange(role)) castMob(m, t.x, t.y)
            }
            Ab.SMOKE -> {
                if (t != null && m.hp < m.maxHp * 0.6f) castMob(m, (m.x + t.x) / 2f, (m.y + t.y) / 2f)
            }
            Ab.FLAME -> {
                if (t != null && d < 3.3f) castMob(m, t.x, t.y)
            }
            Ab.RALLY -> {
                if (t != null && friendsNear(1, m.x, m.y, role.rad, 0).size + friendsNear(1, m.x, m.y, role.rad, 1).size >= 3) castMob(m, m.x, m.y)
            }
            Ab.CAMO, Ab.FORTIFY -> {
                if (t != null && m.hp < m.maxHp * 0.7f) castMob(m, m.x, m.y)
            }
            Ab.MINE -> {
                val n = nearestPlayer(m)
                if (n != null && !m.moving && hyp(n.x - m.x, n.y - m.y) < 9f && hyp(n.x - m.x, n.y - m.y) > 4f) castMob(m, m.x + (n.x - m.x) * 0.2f, m.y + (n.y - m.y) * 0.2f)
            }
            Ab.DASH -> {
                if (t != null && d > role.range * 1.3f && d < 9f) castMob(m, t.x, t.y)
            }
        }
    }

    // ------------------------------------------------------------ هدف مأموریت
    private fun checkObjective(dt: Float) {
        val pl = players()
        if (pl.isEmpty() && mobs.none { it.team == 0 && !it.dead }) {
            state = 2
            endT = 0f
            sfx("lose")
            return
        }
        when (m.type) {
            0, 3 -> {
                val pendingWaves = m.waves > 0 && spawnedWaves < m.waves
                if (enemiesAlive() == 0 && !pendingWaves) win()
            }
            1 -> {
                var all = true
                for (z in zones) {
                    var p = 0
                    var e = 0
                    for (o in mobs) {
                        if (o.dead) continue
                        if (hyp(o.x - z.cx, o.y - z.cy) <= z.r) {
                            if (o.team == 0) p++ else e++
                        }
                    }
                    if (p > 0 && e == 0) z.prog = min(1f, z.prog + 0.16f * min(p, 3) * dt)
                    else if (e > 0 && p == 0) z.prog = max(-1f, z.prog - 0.12f * min(e, 3) * dt)
                    if (z.prog < 1f) all = false
                }
                val pendingWaves = m.waves > 0 && spawnedWaves < m.waves
                if (all && zones.isNotEmpty() && !pendingWaves) win()
            }
            2 -> {
                if (time >= m.time) win()
            }
        }
    }

    private fun win() {
        state = 1
        endT = 0f
        sfx("win")
    }

    fun objectiveText(): String = when (m.type) {
        0 -> "دشمن باقی‌مانده: ${enemiesAlive()}"
        3 -> "دشمن باقی‌مانده: ${enemiesAlive()}"
        1 -> "تصرف نقاط: ${zones.count { it.prog >= 1f }} از ${zones.size}"
        else -> "تا پایان مقاومت: ${max(0, (m.time - time).toInt())} ثانیه"
    }
}
