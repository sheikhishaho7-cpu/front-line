package ir.shahin.frontline

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.Random
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.sin

/**
 * موتور صدا: همه‌ی صداها و موسیقی با کد ساخته می‌شوند (بدون فایل صوتی).
 * موسیقی زمینه با گام شبیه دستگاه شور/بیات ترک و ریتم تنبک.
 */
class SoundEngine {
    private val sr = 22050

    @Volatile
    var sfxOn = true

    @Volatile
    var musicOn = true

    @Volatile
    private var running = false

    @Volatile
    private var built = false

    private var thread: Thread? = null
    private val lock = Any()

    private class Voice(val data: ShortArray, val gain: Float) {
        var pos = 0
    }

    private val voices = ArrayList<Voice>()
    private val sfx = HashMap<String, ShortArray>()
    private var dum = ShortArray(0)
    private var tak = ShortArray(0)
    private var hat = ShortArray(0)
    private var snare = ShortArray(0)

    /** تعریف یک قطعه‌ی موسیقی: گام، ملودی ۳۲گامی، ریتم ۱۶گامی، خط بیس و رنگ صدا */
    private class Track(
        val bpm: Double, val root: Double, val semis: DoubleArray, val mel: IntArray,
        val perc: String, val bass: IntArray, val shape: Int, val decay: Float
    )

    private class Rendered(val plucks: Array<ShortArray>, val basses: Array<ShortArray>, val pad: ShortArray)

    private val bay = doubleArrayOf(0.0, 1.5, 3.0, 5.0, 7.0, 8.0, 10.0, 12.0)
    private val shur = doubleArrayOf(0.0, 1.5, 3.0, 5.0, 7.0, 8.0, 11.0, 12.0)
    private val pent = doubleArrayOf(0.0, 2.0, 4.0, 7.0, 9.0, 12.0, 14.0, 16.0)
    private val hij = doubleArrayOf(0.0, 1.0, 4.0, 5.0, 7.0, 8.0, 11.0, 12.0)
    private val dor = doubleArrayOf(0.0, 2.0, 3.0, 5.0, 7.0, 9.0, 10.0, 12.0)
    private val minr = doubleArrayOf(0.0, 2.0, 3.0, 5.0, 7.0, 8.0, 10.0, 12.0)
    private val mix = doubleArrayOf(0.0, 2.0, 4.0, 5.0, 7.0, 9.0, 10.0, 12.0)
    private val lyd = doubleArrayOf(0.0, 2.0, 4.0, 6.0, 7.0, 9.0, 11.0, 12.0)

    private val bassA = intArrayOf(0, -1, -1, -1, 0, -1, -1, -1, 4, -1, -1, -1, 3, -1, -1, -1)
    private val bassB = intArrayOf(0, -1, 0, -1, -1, -1, 2, -1, 3, -1, 3, -1, -1, -1, 4, -1)
    private val bassC = intArrayOf(0, -1, -1, 0, -1, -1, 0, -1, 4, -1, -1, 4, -1, -1, 3, -1)

    /** ده قطعه: ۰ خانه، ۱ نقشه، ۲ تا ۹ نبرد */
    private val tracks = listOf(
        Track(84.0, 220.0, minr,
            intArrayOf(0, -1, -1, 2, 4, -1, 3, -1, 2, -1, -1, 0, 1, -1, -1, -1, 0, -1, 2, 3, 4, -1, 5, 4, 3, -1, 2, 1, 0, -1, -1, -1),
            "D...s...D.D.s...", bassA, 4, 3.2f),
        Track(96.0, 246.94, dor,
            intArrayOf(0, -1, 2, -1, 4, -1, 3, 2, 0, -1, 2, -1, 3, -1, -1, -1, 4, -1, 5, 4, 3, -1, 2, -1, 0, -1, 1, 0, -1, -1, -1, -1),
            "D..hs..hD.h.s..h", bassB, 3, 3.6f),
        Track(118.0, 196.0, hij,
            intArrayOf(0, 0, 1, -1, 4, -1, 3, 1, 0, -1, 1, 4, 3, -1, 1, -1, 5, -1, 4, 3, 1, 0, 1, -1, 3, -1, 4, 1, 0, -1, -1, -1),
            "DhshDhshDhsDDhsh", bassC, 2, 4.4f),
        Track(126.0, 220.0, minr,
            intArrayOf(0, -1, 3, 4, 5, -1, 4, 3, 0, -1, 3, 4, 7, -1, 5, -1, 5, -1, 4, 3, 2, 3, 4, -1, 3, 2, 0, -1, 2, 0, -1, -1),
            "DtsDtsDtDtsDtsDs", bassC, 1, 5f),
        Track(132.0, 233.08, shur,
            intArrayOf(0, 2, 4, 2, 5, -1, 4, 2, 0, 2, 4, 2, 7, -1, 6, -1, 5, 4, 2, 4, 5, 6, 5, 4, 2, -1, 1, 0, -1, -1, -1, -1),
            "DhDhsDhDDhDhsDsD", bassA, 4, 4.8f),
        Track(110.0, 196.0, bay,
            intArrayOf(0, -1, -1, 3, 4, -1, 3, 1, 0, -1, -1, 1, 3, -1, 4, -1, 5, -1, 4, 3, 4, -1, 5, 6, 5, 4, 3, -1, 1, 0, -1, -1),
            "D.sDD.s.D.sDD.sD", bassB, 3, 4f),
        Track(138.0, 207.65, minr,
            intArrayOf(0, 0, 3, 0, 5, 0, 3, 0, 0, 0, 3, 0, 7, 5, 3, 0, 0, 0, 3, 5, 7, 5, 3, 5, 3, 2, 0, 2, 0, -1, -1, -1),
            "DsDsDsDsDsDsDDss", bassC, 2, 6f),
        Track(100.0, 185.0, lyd,
            intArrayOf(0, -1, -1, 4, 7, -1, 6, 4, 5, -1, -1, 4, 2, -1, -1, -1, 0, -1, 2, 4, 6, 7, 6, 4, 2, -1, 4, 2, 0, -1, -1, -1),
            "D..sD..sD..sD.ss", bassA, 0, 3.4f),
        Track(144.0, 174.61, hij,
            intArrayOf(0, 1, 4, 1, 0, 1, 4, 5, 4, 1, 0, 1, 4, 5, 7, -1, 0, 1, 4, 5, 7, 5, 4, 1, 0, 1, 4, 1, 0, -1, -1, -1),
            "DDsDDsDsDDsDDsss", bassC, 4, 6.2f),
        Track(122.0, 164.81, dor,
            intArrayOf(0, -1, 2, 4, 5, -1, 4, 2, 0, -1, 2, -1, 3, 2, 0, -1, 4, -1, 5, 7, 5, 4, 2, 4, 5, -1, 4, 2, 0, -1, -1, -1),
            "DhsDhDsDDhsDhDss", bassB, 2, 5.2f)
    )
    private val rendered = ArrayList<Rendered>()

    @Volatile
    private var trackIdx = 0

    /** انتخاب قطعه‌ی موسیقی (۰ تا ۹) */
    fun setTrack(i: Int) {
        trackIdx = i.coerceIn(0, 9)
    }
    private val rnd = Random(7)

    fun play(name: String) {
        if (!sfxOn || !built) return
        val d = sfx[name] ?: return
        synchronized(lock) {
            if (voices.size < 40) voices.add(Voice(d, 0.85f))
        }
    }

    @Volatile
    private var gen = 0

    fun start() {
        if (running) return
        running = true
        val my = ++gen
        val t = Thread {
            try {
                loop(my)
            } catch (e: Throwable) {
                // اگر صدا در دستگاه در دسترس نبود، بازی بی‌صدا ادامه می‌دهد
            }
        }
        t.isDaemon = true
        thread = t
        t.start()
    }

    fun stop() {
        running = false
        try {
            thread?.join(500)
        } catch (e: Throwable) {
        }
        thread = null
        synchronized(lock) { voices.clear() }
    }

    // ------------------------------------------------------------ ساخت صداها

    private fun osc(shape: Int, ph: Double): Float {
        return when (shape) {
            0 -> sin(ph).toFloat()
            1 -> if (sin(ph) >= 0.0) 0.5f else -0.5f
            2 -> {
                val x = ph / (2.0 * PI)
                (2.0 * (x - floor(x)) - 1.0).toFloat() * 0.6f
            }
            3 -> {
                val x = ph / (2.0 * PI)
                val f = x - floor(x)
                (if (f < 0.5) 4.0 * f - 1.0 else 3.0 - 4.0 * f).toFloat()
            }
            else -> (sin(ph) + 0.5 * sin(2 * ph) + 0.28 * sin(3 * ph) + 0.12 * sin(4 * ph)).toFloat() * 0.6f
        }
    }

    private fun note(freq: Double, sec: Float, shape: Int, vol: Float, attack: Float, decay: Float): FloatArray {
        val n = (sec * sr).toInt()
        val out = FloatArray(n)
        for (i in 0 until n) {
            val t = i.toFloat() / sr
            val a = if (t < attack) t / attack else 1f
            val e = a * exp(-t * decay)
            out[i] = osc(shape, 2.0 * PI * freq * t) * e * vol
        }
        return out
    }

    private fun sweep(f0: Double, f1: Double, sec: Float, shape: Int, vol: Float, decay: Float): FloatArray {
        val n = (sec * sr).toInt()
        val out = FloatArray(n)
        var ph = 0.0
        for (i in 0 until n) {
            val t = i.toFloat() / sr
            val f = f0 + (f1 - f0) * (i.toDouble() / n)
            ph += 2.0 * PI * f / sr
            val a = if (t < 0.004f) t / 0.004f else 1f
            out[i] = osc(shape, ph) * a * exp(-t * decay) * vol
        }
        return out
    }

    private fun noise(sec: Float, vol: Float, decay: Float): FloatArray {
        val n = (sec * sr).toInt()
        val out = FloatArray(n)
        for (i in 0 until n) {
            val t = i.toFloat() / sr
            out[i] = (rnd.nextFloat() * 2f - 1f) * exp(-t * decay) * vol
        }
        return out
    }

    private fun smooth(a: FloatArray, k: Float): FloatArray {
        var y = 0f
        for (i in a.indices) {
            y += k * (a[i] - y)
            a[i] = y
        }
        return a
    }

    private fun layer(total: Float, vararg parts: Pair<Float, FloatArray>): FloatArray {
        val out = FloatArray((total * sr).toInt())
        for (p in parts) {
            val off = (p.first * sr).toInt()
            val d = p.second
            var i = 0
            while (i < d.size && off + i < out.size) {
                out[off + i] += d[i]
                i++
            }
        }
        return out
    }

    private fun add(a: FloatArray, b: FloatArray): FloatArray {
        val out = FloatArray(maxOf(a.size, b.size))
        for (i in a.indices) out[i] += a[i]
        for (i in b.indices) out[i] += b[i]
        return out
    }

    private fun toShorts(f: FloatArray, vol: Float): ShortArray {
        val out = ShortArray(f.size)
        for (i in f.indices) {
            val v = (f[i] * vol * 32767f).coerceIn(-32767f, 32767f)
            out[i] = v.toInt().toShort()
        }
        return out
    }

    private fun buildSounds() {
        if (built) return
        sfx["click"] = toShorts(note(900.0, 0.06f, 0, 1f, 0.002f, 50f), 0.55f)
        sfx["tick"] = toShorts(note(1500.0, 0.04f, 0, 1f, 0.001f, 80f), 0.5f)
        sfx["correct"] = toShorts(
            layer(
                0.7f,
                0f to note(523.25, 0.3f, 3, 0.9f, 0.004f, 8f),
                0.07f to note(659.25, 0.3f, 3, 0.9f, 0.004f, 8f),
                0.14f to note(783.99, 0.3f, 3, 0.9f, 0.004f, 8f),
                0.21f to note(1046.5, 0.45f, 3, 0.9f, 0.004f, 6f)
            ), 0.55f
        )
        sfx["wrong"] = toShorts(
            add(
                sweep(230.0, 100.0, 0.4f, 2, 0.8f, 3f),
                sweep(244.0, 108.0, 0.4f, 2, 0.6f, 3f)
            ), 0.5f
        )
        sfx["coin"] = toShorts(
            layer(
                0.4f,
                0f to note(987.77, 0.1f, 0, 0.8f, 0.002f, 16f),
                0.07f to note(1318.51, 0.3f, 0, 0.8f, 0.002f, 8f)
            ), 0.5f
        )
        sfx["hit"] = toShorts(
            add(smooth(noise(0.2f, 1f, 20f), 0.5f), sweep(170.0, 55.0, 0.22f, 0, 1f, 12f)), 0.8f
        )
        sfx["boom"] = toShorts(
            add(smooth(noise(1.0f, 1f, 3.5f), 0.12f), sweep(120.0, 32.0, 0.9f, 0, 1f, 3f)), 0.9f
        )
        sfx["win"] = toShorts(
            layer(
                1.9f,
                0f to note(523.25, 0.3f, 4, 0.8f, 0.005f, 5f),
                0.18f to note(659.25, 0.3f, 4, 0.8f, 0.005f, 5f),
                0.36f to note(783.99, 0.3f, 4, 0.8f, 0.005f, 5f),
                0.54f to note(1046.5, 0.5f, 4, 0.8f, 0.005f, 4f),
                0.9f to note(783.99, 0.9f, 4, 0.6f, 0.005f, 2.5f),
                0.9f to note(1046.5, 0.95f, 4, 0.6f, 0.005f, 2.5f),
                0.9f to note(1318.51, 0.95f, 4, 0.6f, 0.005f, 2.5f)
            ), 0.55f
        )
        sfx["lose"] = toShorts(
            layer(
                1.5f,
                0f to note(392.0, 0.35f, 2, 0.7f, 0.01f, 5f),
                0.28f to note(329.63, 0.35f, 2, 0.7f, 0.01f, 5f),
                0.56f to note(261.63, 0.35f, 2, 0.7f, 0.01f, 5f),
                0.86f to note(196.0, 0.6f, 2, 0.7f, 0.01f, 3.5f)
            ), 0.45f
        )
        sfx["star"] = toShorts(sweep(600.0, 1600.0, 0.32f, 3, 0.9f, 5f), 0.5f)
        sfx["power"] = toShorts(sweep(300.0, 950.0, 0.28f, 0, 0.9f, 6f), 0.5f)
        sfx["whoosh"] = toShorts(smooth(noise(0.45f, 1f, 5f), 0.25f), 0.7f)
        sfx["shot"] = toShorts(add(smooth(noise(0.14f, 1f, 30f), 0.6f), sweep(900.0, 200.0, 0.1f, 2, 0.6f, 30f)), 0.6f)
        sfx["mg"] = toShorts(
            layer(0.3f,
                0f to add(smooth(noise(0.07f, 1f, 45f), 0.55f), sweep(700.0, 180.0, 0.06f, 2, 0.5f, 40f)),
                0.09f to add(smooth(noise(0.07f, 1f, 45f), 0.55f), sweep(700.0, 180.0, 0.06f, 2, 0.5f, 40f)),
                0.18f to add(smooth(noise(0.07f, 1f, 45f), 0.55f), sweep(700.0, 180.0, 0.06f, 2, 0.5f, 40f))), 0.5f)
        sfx["cannon"] = toShorts(add(smooth(noise(0.5f, 1f, 7f), 0.2f), sweep(190.0, 45.0, 0.45f, 0, 1f, 6f)), 0.85f)
        sfx["rocket"] = toShorts(add(smooth(noise(0.6f, 0.9f, 3.5f), 0.3f), sweep(300.0, 900.0, 0.5f, 2, 0.4f, 3f)), 0.6f)
        sfx["explode"] = toShorts(add(smooth(noise(1.2f, 1f, 3f), 0.1f), sweep(100.0, 28.0, 1.0f, 0, 1f, 2.6f)), 0.95f)
        sfx["die"] = toShorts(sweep(380.0, 90.0, 0.3f, 2, 0.7f, 6f), 0.4f)
        sfx["heal"] = toShorts(layer(0.5f,
            0f to note(659.25, 0.2f, 3, 0.8f, 0.004f, 8f),
            0.1f to note(880.0, 0.3f, 3, 0.8f, 0.004f, 7f)), 0.5f)
        sfx["order"] = toShorts(layer(0.2f,
            0f to note(520.0, 0.07f, 0, 0.8f, 0.002f, 35f),
            0.06f to note(700.0, 0.08f, 0, 0.8f, 0.002f, 35f)), 0.45f)
        sfx["alarm"] = toShorts(layer(1.0f,
            0f to note(740.0, 0.22f, 2, 0.8f, 0.01f, 3f),
            0.25f to note(560.0, 0.22f, 2, 0.8f, 0.01f, 3f),
            0.5f to note(740.0, 0.22f, 2, 0.8f, 0.01f, 3f),
            0.75f to note(560.0, 0.22f, 2, 0.8f, 0.01f, 3f)), 0.5f)
        sfx["whistle"] = toShorts(sweep(2000.0, 700.0, 0.9f, 3, 0.6f, 2f), 0.4f)
        sfx["flame"] = toShorts(smooth(noise(0.6f, 1f, 2.5f), 0.35f), 0.6f)

        // گام شبیه بیات ترک روی ر (D): ر، می‌کرن، فا، سل، لا، سی‌بمل، دو، ر
        for (tr in tracks) {
            val pl = Array(8) { k ->
                toShorts(note(tr.root * Math.pow(2.0, tr.semis[k] / 12.0), 1.1f, tr.shape, 0.9f, 0.003f, tr.decay), 0.9f)
            }
            val bs = Array(8) { k ->
                toShorts(note(tr.root * Math.pow(2.0, tr.semis[k] / 12.0) / 2.0, 0.5f, 3, 1f, 0.005f, 6f), 0.8f)
            }
            val pd = toShorts(
                add(note(tr.root / 4.0, 3.2f, 0, 0.5f, 0.5f, 0.55f), note(tr.root * 1.5 / 4.0, 3.2f, 0, 0.35f, 0.5f, 0.55f)), 0.8f
            )
            rendered.add(Rendered(pl, bs, pd))
        }
        hat = toShorts(noise(0.05f, 0.35f, 90f), 0.5f)
        snare = toShorts(add(noise(0.14f, 0.7f, 28f), note(210.0, 0.1f, 0, 0.5f, 0.001f, 40f)), 0.6f)
        dum = toShorts(
            add(sweep(150.0, 62.0, 0.28f, 0, 1f, 14f), smooth(noise(0.05f, 0.4f, 60f), 0.6f)), 0.9f
        )
        tak = toShorts(
            add(noise(0.1f, 0.6f, 45f), note(1900.0, 0.05f, 0, 0.5f, 0.001f, 70f)), 0.6f
        )
        built = true
    }

    // ------------------------------------------------------------ پخش

    private fun loop(my: Int) {
        synchronized(lock) { buildSounds() }
        val chunk = 512
        val minBuf = AudioTrack.getMinBufferSize(
            sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sr)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBuf, chunk * 2 * 4))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        val acc = IntArray(chunk)
        val out = ShortArray(chunk)
        var untilStep = 0
        var step = 0
        var curTrack = -1

        try {
            track.play()
            while (running && gen == my) {
                untilStep -= chunk
                if (untilStep <= 0) {
                    val ti = trackIdx.coerceIn(0, tracks.size - 1)
                    if (ti != curTrack) {
                        curTrack = ti
                        step = 0
                    }
                    val tr = tracks[ti]
                    val rd = rendered[ti]
                    untilStep += (sr * 60.0 / tr.bpm / 2.0).toInt()
                    if (musicOn) {
                        synchronized(lock) {
                            if (step % 16 == 0) voices.add(Voice(rd.pad, 0.16f))
                            when (tr.perc[step % 16]) {
                                'D' -> voices.add(Voice(dum, 0.42f))
                                't' -> voices.add(Voice(tak, 0.3f))
                                'h' -> voices.add(Voice(hat, 0.22f))
                                's' -> voices.add(Voice(snare, 0.3f))
                                else -> {}
                            }
                            val b = tr.bass[step % 16]
                            if (b >= 0 && b < 8) voices.add(Voice(rd.basses[b], 0.34f))
                            val m = tr.mel[step % 32]
                            if (m >= 0 && m < 8) voices.add(Voice(rd.plucks[m], 0.3f))
                        }
                    }
                    step = (step + 1) % 32
                }

                java.util.Arrays.fill(acc, 0)
                synchronized(lock) {
                    val it = voices.iterator()
                    while (it.hasNext()) {
                        val v = it.next()
                        val d = v.data
                        var p = v.pos
                        var j = 0
                        while (j < chunk && p < d.size) {
                            acc[j] += (d[p] * v.gain).toInt()
                            p++
                            j++
                        }
                        v.pos = p
                        if (p >= d.size) it.remove()
                    }
                }
                for (j in 0 until chunk) out[j] = acc[j].coerceIn(-32767, 32767).toShort()
                track.write(out, 0, chunk)
            }
        } finally {
            try {
                track.stop()
            } catch (e: Throwable) {
            }
            track.release()
        }
    }
}
